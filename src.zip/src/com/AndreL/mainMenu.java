package com.AndreL;

import java.util.*;

public class mainMenu {

    private Scanner scan = new Scanner(System.in);
    private convivioDei novo;
    private convivioDei repl;
    private Locais local;
    private Ficheiros fich = new Ficheiros();
    private baseDadosDei base;

    List<String> inDei;

    protected mainMenu() {
        base = new baseDadosDei();
        base.readFromOb();
        base.readFromObLocals();
        System.out.println(base.locais);

        try{
            atualizaData();
        }catch(NullPointerException e){
            e.fillInStackTrace();
        }

    }

    // Gerimento de inscritos

    /**
     * cria pessoa e coloca em ficheiro objeto
     * @param nome
     * @param numero
     * @param mail
     * @param car
     * @param pass
     * @param tipo
     * @param perfil
     */

    protected void getIn(String nome, String numero, String mail, String car, String pass,String tipo,String perfil){

        convivioDei novo;
        switch (tipo){
            case "Professor":
                novo = new professor(car,pass,nome,numero,perfil,mail); // cria objeto
                base.storeIn(novo);                                     //guarda na lista e de seguida no ficheiro
                System.out.println("Foi inscrito no convivio!");
                checkin(numero,pass);                                   //atribui ao utilizador o objeto
                break;
            case "Aluno":
                novo = new aluno(car,pass,nome,numero,perfil,mail);
                base.storeIn(novo);
                System.out.println("Foi inscrito no convivio!");
                checkin(numero,pass);
                break;
            case "Auxiliar":
                novo = new auxiliar(car,pass,nome,numero,perfil,mail);
                base.storeIn(novo);
                System.out.println("Foi inscrito no convivio!");
                checkin(numero,pass);
                break;
            default:
                System.out.println("Nada foi inserido");
                break;
        }

    }


    /**
     * verficar existencia na ficheiro do DEI
     * @param id
     * @return
     */

    protected List<String> checkExistance(String id){

        List<String> personal = new ArrayList<>();
        for(String[] w: base.dei) {                //obtem o array com as informações das pessoas
            for (int i = 0; i < w.length; i++) {
                if (w[i].equals(id)) {             // se o id introudzido for igual a um id na base de dados
                    System.out.println("O seu id é existente na comunidade do DEI"); //existe no dei
                    for (int p = 0 ; p < w.length ; p++){
                        personal.add(w[p]);        //coloca as informações da pessoa numa lista de arrays
                    }
                    return personal;   //retorna a lista
                }
            }
        }
        System.out.println("O seu id é inexistente na comunidade do DEI");
        return personal;
    }

    /**
     * verificar se já está inscrito
     * @param id_n
     * @param pass
     * @return
     */

    protected int checkin(String id_n, String pass){

        int true_info = 0; // informação mutua

        for(convivioDei w:base.insc){
            if((w.id.equals(id_n) && w.password.equals(pass))){   //verificar se o id e a password já são existentes
                true_info = 2;        //atribui 2 que significa que encontrou a pass e o id
                this.novo = w;        //o utilizador fica atribuido com o objeto que lhe compete
            }else if((w.id.equals(id_n) && w.password != (pass))){   //verificar se só o id existe
                true_info = 1;            //o id existe mas nao está inscrito
                System.out.println(" a");

            }else if(w.nome.equals(id_n) && w.password != (pass)){   //verificação por nome
                System.out.println("Este utilizador já está inscrito!");
                return 3;
            }
        }

        /**
         * verificações das informações mutuas para passar ao passo seguinte
         */

        if(true_info == 2) {
            System.out.println("Login efetuado com sucesso.");
            System.out.println(novo.id);
            return 1;
        }else if(true_info == 1){
            System.out.println("A palavra-passe ou id estão incorretos");
            return -1;
        }else
            System.out.println(" incorretos");

        return 0;  //
    }

    /**
     * gestor de login e inscrições
     *  este metodo gere todos os anteriores e é que os chama
     *  @param numero
     * @param pass
     * @return
     */

    protected int loginfo(String numero, String pass){

        inDei = new ArrayList<>();  // inicializa a lista vazia
        int inLog;   // valor para confirmar existencia

        inDei = checkExistance(numero); //obtem a lista com as informações do utilizador
        // Presença na comunidade do DEI
        if(inDei.size() == 4 ){   //verifica se a informação compete ao numero padrão na base de dadoss
            System.out.println("Passar ao login/inscrição");
            inLog = checkin(numero,pass);  // verifica se está inscrito
        }else{
            System.out.println("Este ID não está na Comunidade do DEI");
            inLog = 2;
        }
        // Presença na lista de inscritos

        if(inLog == 1 || (numero.equals("admin")&&pass.equals("admin"))){
            System.out.println("Segue para os menus");
        }else if(inLog == 0){
            System.out.println("Cria perfil, depois seleciona locais");
            System.out.println(inDei);


        }else if(inLog == -1){
            return -1;
        }

        return inLog;

    }

    // Manipulação de dados

    /**
     * atualização de dados
     */

    protected void atualizaData(){

        base.sortList();   // ordena a lista
        fich.writeFileOb("C:\\Users\\killz\\Desktop\\FCTUC\\2º ANO\\1º_Semestre\\POO\\ProjetoPoo\\Files\\testObjeto",base.insc);  // escreve o utilizador atualizada no ficheiro objeto
        base.readFromOb();  // obtem a lista de volta
        checkin(this.novo.id,this.novo.password); //atualiza o utilizador depois de mudanças feitas nas suas variaveis
        fich.writeFileObLocals("C:\\Users\\killz\\Desktop\\FCTUC\\2º ANO\\1º_Semestre\\POO\\ProjetoPoo\\Files\\LocaisObject",base.locais); // escreve a lista aturalizada em ficheiro objeto

    }

    /**
     * selecionar locais
     * @param x
     * @return
     */

    protected int selectPlaces(int x) {

        int anwser = 0;      // obter confirmação se o local esta cheio, se já está inscrito ou nao
        int maximo;          // numero possivel de inscrições em locais do utilizador

        /**
         * exceção para um ponteiro nulo, no caso de ter acabado de inscrever e nao ter locais ainda em registo
         */

        try {
            maximo = 5 - this.novo.going.size(); //valor possivel de locais a escolher
        } catch (NullPointerException e) {
            System.out.println("Ponteiro nulo");
            maximo = 5;
            atualizaData();                    // atualiza os dados
        }

        int last = base.locais.size();

        if (maximo > 0) {

            System.out.printf("Selecione o local a adicionar: ");

            if ((x >= 0 && x <= last) && checkup(x) != 1) {  // verificação se o utilizador já obtem este local

                if (base.locais.get(x).getClass().toString().contains("bares")) { // se for bar

                    if (((bares) base.locais.get(x)).getLotacao() != 0 || ((this.novo.perfil.equals("Boemio") && ((bares) base.locais.get(x)).getLotacao() == 0))){ //enquanto houver lugar ou se for boemio e nao houver lugar (boemio tem precedencia)

                        this.novo.going.add(base.locais.get(x));
                        repl = base.locais.get(x).storeGuest(this.novo);
                        maximo--;
                        

                        if (((bares) base.locais.get(x)).getLotacao() == 0 && this.novo.perfil.equals("Boemio") && repl.equals(null)) {
                            maximo++;
                        }

                        System.out.println("Pode adicionar mais " + maximo + " local/ais à sua lista");

                        try {
                            if (!(repl.equals(null))) {
                                base.replaceInsc(repl);
                            }
                        } catch (NullPointerException e) {

                        }


                    }else {
                        System.out.println("O Local está cheio.");
                        anwser = 1;
                        return anwser;
                    }

                }else {
                    for (int p = 0; p < this.novo.going.size(); p++) {
                        if ((this.novo.going.get(p).descricaoLocal.equals(base.locais.get(x).descricaoLocal))) {
                            System.out.println("Já está inscrito neste Locais");
                            anwser = 2;
                            return anwser;
                        }
                    }
                    if(anwser != 2) {
                        this.novo.going.add(base.locais.get(x));
                        base.locais.get(x).getInside(this.novo);
                        maximo--;
                        System.out.println("Pode adicionar mais " + maximo + " local/ais à sua lista");
                    }
                }
            }else{
                anwser = 3;
            }
        }
        base.sortList();
        System.out.println(anwser);
        return anwser;
    }

    /**
     * desinscrição em convivio
     */

    protected void desinscreve(){

        int comp = this.novo.going.size();

        for(int  i = 0 ; i < base.locais.size(); i++){
            for(int j = 0; j < base.locais.get(i).inLocais.size(); j++) {
                if (base.locais.get(i).inLocais.get(j).id.equals(this.novo.id)) { // verificar se o objeto que está na lista é o mesmo com que estamos a lidar
                    if(base.locais.get(i).getClass().toString().contains("bares")){ // para o caso de ser bar e ter que eliminar da guest tambem
                        ((bares)base.locais.get(i)).getGuest().remove(base.locais.get(i).inLocais.get(j));  // retira da guest list
                        ((bares)base.locais.get(i)).restore_lotacao();  // restaura a lotacao
                        ((bares)base.locais.get(i)).restore_t();  // restaura a lotacao da guest
                    }
                    base.locais.get(i).lowProfit(base.locais.get(i).inLocais.get(j)); // diminui o lucro do local caso o tenho
                    base.locais.get(i).inLocais.remove(base.locais.get(i).inLocais.get(j)); // tira finalmente o inscrito do local
                }
            }
        }
        base.insc.remove(this.novo); // remove da base de inscritos
        fich.removeInscrito("C:\\Users\\killz\\Desktop\\FCTUC\\2º ANO\\1º_Semestre\\POO\\ProjetoPoo\\Files\\baseDadosInscritos",this.novo.id); //remove do ficheiro de texto
        atualizaData(); // atualiza os dados
        System.out.println("----A sair da aplicação----");
        System.exit(0);
    }

    /**
     * verificar se está inscrito no local
     * @param x
     * @return
     */


    protected int checkup(int x){

        int g = 0;
        for (int i = 0 ; i < this.novo.going.size(); i++){
            if ((this.novo.going.get(i).descricaoLocal.equals(base.locais.get(x).descricaoLocal))) {
                g = 1;
                System.out.println("ja esta inscrito");
                break;
            }
        }
        System.out.println(g);
        return g;
    }

    /**
     * remover local da lista de locais do objeto
     * @param x
     * @return
     */

    protected int removeLocal(int x) {

        // a aplicação desta função é igual á aplica da desinscrição a menos que esta é focada num só local

        int eliminatorio = 0;


            for (int j = 0; j < base.locais.get(x).inLocais.size(); j++) {
                if (base.locais.get(x).inLocais.get(j).id.equals(this.novo.id)) {
                    if (base.locais.get(x).getClass().toString().contains("bares")) {
                        ((bares) base.locais.get(x)).getGuest().remove(base.locais.get(x).inLocais.get(j));
                        ((bares) base.locais.get(x)).restore_lotacao();
                        ((bares) base.locais.get(x)).restore_t();
                    }
                    for (int i = 0; i < this.novo.going.size(); i++) {
                        if (this.novo.going.get(i).descricaoLocal.equals(base.locais.get(x).descricaoLocal)) {
                            this.novo.going.remove(i);
                            break;
                        }
                    }
                    base.locais.get(x).lowProfit(base.locais.get(x).inLocais.get(j));
                    base.locais.get(x).inLocais.remove(base.locais.get(x).inLocais.get(j));
                    eliminatorio = 1;
                    break;
                }
            }
        System.out.println(this.novo.going);
        atualizaData();
        System.out.println(eliminatorio);
        return eliminatorio;
    }

    // Gerimento de Locais

    /**
     * adicionar locais em consola
     */

    protected void addLocal(){

        System.out.printf("Qual o tipo de Local a adicionar? [bares,exposicoes,jardins,areas desportivas\n->");
        String loc = scan.nextLine();

        String desc,coord,desporto, arte;  // desc = descricao do local , cooord = gps
        int lot;                           // lot = lotacao do local quando se aplica
        double area, consMin,ingresso, t;  // consMin = consumo minimo, t = percentagem capaz para guest List quando se aplica

        switch (loc){
            case "bares":
                System.out.println("Qual o nome do bar?");
                desc = scan.nextLine();
                System.out.println("Coordenadas");
                coord = scan.nextLine();
                System.out.println("Lotacao");
                lot = scan.nextInt();
                System.out.println("Consumo Minimo");
                consMin = scan.nextDouble();
                System.out.println("Percentagem de inscritos para guest list: ");
                t = scan.nextDouble();
                scan.nextLine();
                base.readFromObLocals();
                this.local = new bares(desc,consMin,lot,coord,t);
                base.storeLoc(this.local);
                base.readFromObLocals();
                break;
            case "jardins":
                System.out.println("Qual o nome do Jardim?");
                desc = scan.nextLine();
                System.out.println("Coordenadas");
                coord = scan.nextLine();
                System.out.println("Area");
                area = scan.nextDouble();
                scan.nextLine();
                base.readFromObLocals();
                this.local = new jardins(desc,coord,area);
                base.storeLoc(this.local);
                base.readFromObLocals();
                break;
            case "areas desportivas":
                System.out.println("Qual o nome da Area Desportiva?");
                desc = scan.nextLine();
                System.out.println("Coordenadas");
                coord = scan.nextLine();
                System.out.println("Desporto");
                desporto = scan.nextLine();
                base.readFromObLocals();
                this.local = new areaDesportiva(desc,coord,desporto);
                base.storeLoc(this.local);
                base.readFromObLocals();
                break;
            case "exposicoes":
                System.out.println("Qual o nome da Exposicao?");
                desc = scan.nextLine();
                System.out.println("Coordenadas");
                coord = scan.nextLine();
                System.out.println("Tipo de arte");
                arte = scan.nextLine();
                System.out.println("Ingresso de Entrada");
                ingresso = scan.nextDouble();
                scan.nextLine();
                base.readFromObLocals();
                this.local = new exposicao(arte,ingresso,desc,coord);
                base.storeLoc(this.local);
                base.readFromObLocals();
                break;
            default:
                System.out.println("Nada foi inserido");

        }


    }

    // Gestão do Programa

    /**
     *
     * métodos para obter variaveis protegida pelo private
     *
     * @return
     */

    public Scanner getScan() {
        return scan;
    }

    public convivioDei getNovo() {
        return novo;
    }

    public convivioDei getRepl() {
        return repl;
    }

    public Locais getLocal() {
        return local;
    }

    public Ficheiros getFich() {
        return fich;
    }

    public baseDadosDei getBase() {
        return base;
    }

    public List<String> getInDei() {
        return inDei;
    }
}
