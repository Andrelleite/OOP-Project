package com.AndreL;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.LinkedList;
import java.util.List;

/**
 *
 *
 * gestor da base de dados e ficheiros do convivio
 *
 *
 */


public class baseDadosDei {

    protected List<String[]> dei = new ArrayList<>();   //lista de pessoas em ficheiro de texto por array
    protected List<String[]> nomes = new LinkedList<>();  // lista de nomes de cada pessoa
    protected List<Locais> locais = new LinkedList<>();  // lista de locais
    protected List<convivioDei> insc = new LinkedList<>(); // lista de pessoas registadas
    Ficheiros fich = new Ficheiros(); // utilização necessária dos metodos na classe Ficheiros

    /**
     *
     * construtor da classe
     * faz upload da informação em texto
     *
     */

    public baseDadosDei(){

        dei = fich.readFile("C:\\Users\\killz\\Desktop\\FCTUC\\2º ANO\\1º_Semestre\\POO\\ProjetoPoo\\Files\\baseDadosDei",dei);  // le do ficheiro de texto e guarda em lista de array
        readFromOb();  // le o ficheiro de objetos de inscritos
        readFromObLocals();  // le o ficheiro de objetos de locais

    }

//    Pessoas

    /**
     * le do ficheiro de texto de inscritos
     */

    public void readFrom() {
        nomes = fich.readFile("C:\\Users\\killz\\Desktop\\FCTUC\\2º ANO\\1º_Semestre\\POO\\ProjetoPoo\\Files\\baseDadosInscritos",nomes);
//        System.out.println(nomes);
    }

    /**
     * guarda o novo inscrito na lista e depois guarda em ficheiro
     * @param inscrito
     */

    public void storeIn(convivioDei inscrito){
        insc.add(inscrito);
        fich.writeFileOb("C:\\Users\\killz\\Desktop\\FCTUC\\2º ANO\\1º_Semestre\\POO\\ProjetoPoo\\Files\\testObjeto",insc);
        System.out.println("--List Updated--");
        System.out.println(insc);
    }

    /**
     * obter a lista de inscritos
     * @return
     */

    public List<convivioDei> getInscritos() {
        return insc;
    }

    /**
     * obter lista de inscritos a partir de ficheiro de objetos
     * @return
     */

    public List<convivioDei> readFromOb(){
        insc = fich.readFileOb("C:\\Users\\killz\\Desktop\\FCTUC\\2º ANO\\1º_Semestre\\POO\\ProjetoPoo\\Files\\testObjeto");
        System.out.println("Upload de dados sobre inscritos- Feito!");
        return insc;
    }

    /**
     * remove um objeto e mete um novo atualizado
     * permite ter sempre 1 de cada objeto guardado e nao ter objetos diferentes em memoria
     * @param pessoa
     */

    public void replaceInsc(convivioDei pessoa){

        for(int i = 0 ; i < insc.size(); i++){
            if(this.insc.get(i).id.equals(pessoa.id)){
                this.insc.remove(this.insc.get(i));
                storeIn(pessoa);
                break;
            }
        }
    }

//    Locais

    /**
     * guarda locais em ficheiro texto
     * @param loc
     */

    public void storeLoc(Locais loc){
        locais.add(loc);
        fich.writeFileObLocals("C:\\Users\\killz\\Desktop\\FCTUC\\2º ANO\\1º_Semestre\\POO\\ProjetoPoo\\Files\\LocaisObject",locais);
        System.out.println("--List Updated--");
        System.out.println(locais);
    }

    /**
     * le do ficheiro de objetos para locais
     * @return
     */

    public List<Locais> readFromObLocals(){
        locais = fich.readFileObLocals("C:\\Users\\killz\\Desktop\\FCTUC\\2º ANO\\1º_Semestre\\POO\\ProjetoPoo\\Files\\LocaisObject");
        System.out.println("Upload de dados sobre Locais - Feito!");
        return locais;
    }

    /**
     * mete a lista por ordem de inscritos
     */

    public void sortList(){

        int comp = this.locais.size();
        Locais x;

        for(int i = 0; i < comp; i++){
            for(int j = 0; j < comp-1; j++){
                if(this.locais.get(j).inLocais.size() <= this.locais.get(j+1).inLocais.size()){
                    x = this.locais.get(j+1);
                    this.locais.remove(j+1);
                    this.locais.add(j,x);
                }
            }
        }

        System.out.println(this.locais);
    }

}

