package com.AndreL;

import java.io.Serializable;
import java.util.LinkedList;
import java.util.List;

/**
 *
 * objetos do tipo locais
 *
 */

public class Locais implements Serializable {

    Ficheiros fich = new Ficheiros();
    protected String gps;
    protected String descricaoLocal;
    protected List<convivioDei> inLocais = new LinkedList<>(); // lista de objetos do tipo convivioDei

    /**
     * construtor da classe
     */

    public Locais() {

        this.gps = "0.0ºN ";
        this.descricaoLocal = "default";
    }

    public String getGps() {
        return gps;
    }

    public List<convivioDei> getInside(convivioDei pessoa){
        this.inLocais.add(pessoa);
        System.out.println(this.inLocais);
        return this.inLocais;
    }

    public void storeLocal(){
        fich.writeFileLocals("C:\\Users\\killz\\Desktop\\FCTUC\\2º ANO\\1º_Semestre\\POO\\ProjetoPoo\\Files\\Locais",Locais.this);
    }

    public void lowProfit(convivioDei pessoa){
        System.out.println("Nao detem lucros.");
    }

    public convivioDei storeGuest(convivioDei pessoa){
        convivioDei novo;
        novo = null;
        return novo;
    }

}


/**
 * objeto do tipo exposicao
 */
class exposicao extends Locais{

    private String arte;
    private double ingresso;
    private double lucro;

    public exposicao(String arte, double ingresso, String nome, String gps) {
        this.arte = arte;
        this.ingresso = ingresso;
        super.gps = gps;
        super.descricaoLocal = nome;
        storeLocal();
    }

    public String getArte() {
        return arte;
    }

    public double getIngresso() {
        return ingresso;
    }

    public double getLucro() {
        return lucro;
    }

    @Override
    public List<convivioDei> getInside(convivioDei pessoa){
        super.inLocais.add(pessoa);
        if(pessoa.getClass().toString().contains("aluno")){
            this.lucro += (0.9*this.ingresso);
        }else{
            this.lucro += this.ingresso;
        }
        System.out.println(super.inLocais);
        return super.inLocais;
    }

    @Override
    public void storeLocal(){
        fich.writeFileLocals("C:\\Users\\killz\\Desktop\\FCTUC\\2º ANO\\1º_Semestre\\POO\\ProjetoPoo\\Files\\Locais",exposicao.this);
    }

    @Override
    public void lowProfit(convivioDei pessoa){

        if(pessoa.getClass().toString().contains("aluno")){
            this.lucro -= ((aluno)pessoa).getPromo()*this.ingresso;
        }else{
            this.lucro -= ingresso;
        }
    }

}

/**
 * objeto do tipo bares
 */

class bares extends Locais{

    protected int t;
    private List<convivioDei> guest = new LinkedList<>();
    private double consumoMin;
    private int lotacao , lotacaof, tf;
    private double lucro;

    public bares(String nomeBar, double consumoMin, int lotacao, String gps, double guestLot) {
        super.descricaoLocal = nomeBar;
        this.consumoMin = consumoMin;
        this.lotacao = this.lotacaof = lotacao;
        super.gps = gps;
        this.t = this.tf = (int)(guestLot * lotacao);
        storeLocal();
        System.out.println("Lotacao Maximo: "+this.lotacaof+" | Lotacao da Guest List: "+this.tf);
    }

    public double getConsumoMin() {
        return consumoMin;
    }

    public int getLotacaoF() {
        return lotacaof;
    }

    public int getLotacao() {
        return lotacao;
    }

    public double getLucro() {
        return lucro;
    }

    @Override
    public void storeLocal(){
        fich.writeFileLocals("C:\\Users\\killz\\Desktop\\FCTUC\\2º ANO\\1º_Semestre\\POO\\ProjetoPoo\\Files\\Locais",bares.this);
    }

    @Override
    public List<convivioDei> getInside(convivioDei pessoa){
        super.inLocais.add(pessoa);
        if(pessoa.getClass().toString().contains("aluno")){
            this.lucro += this.consumoMin - (((aluno)pessoa).getPromo()*this.consumoMin);
        }else{
            this.lucro += this.consumoMin;
        }
        System.out.println(super.inLocais);
        return super.inLocais;
    }

    @Override
    public void lowProfit(convivioDei pessoa){

        if(pessoa.getClass().toString().contains("aluno")){
            this.lucro -= 0.9*this.consumoMin;
        }else{
            this.lucro -= this.consumoMin;

        }
    }

    @Override
    public convivioDei storeGuest(convivioDei pessoa){

        boolean state =  false;
        convivioDei fora = null;
        if((this.lotacao > 0 && this.lotacao <= this.lotacaof && t == 0)||(this.t == 0 && this.lotacao == 0 && pessoa.perfil.equals("Boemio"))){
            for(int i = guest.size()-1 ; i >= 0 ; i--){
                if((!(guest.get(i).perfil.equals("Boemio")) && pessoa.perfil.equals("Boemio")) && this.lotacao > 0){
                    guest.add(i,pessoa);
                    guest.remove(i+1);
                    state = true;
                    break;
                }else if((!(guest.get(i).perfil.equals("Boemio")) && pessoa.perfil.equals("Boemio")) && this.lotacao == 0){
                    guest.add(i,pessoa);
                    lowProfit(guest.get(i+1));
                    System.out.println(guest.get(i+1).going);
                    int comp = guest.get(i+1).going.size();
                    System.out.println(comp);
                    for(int p = 0; p < comp; p++) {
                        if(guest.get(i+1).going.get(p).descricaoLocal.equals(this.descricaoLocal)){
                            guest.get(i+1).going.remove(guest.get(i+1).going.get(p));
                            fora = guest.get(i+1);
                            System.out.println(guest.get(i+1));
                            System.out.println(guest.get(i+1).going);
                            break;
                        }
                    }
                    guest.remove(i+1);
                    state = true;
                    this.inLocais.remove(this.inLocais.size()-1); //Retira o ultimo a estar inscrito no local
                    getInside(pessoa);
                    return fora;
                }
            }
            if(this.lotacao > 0) {
                getInside(pessoa);
                this.lotacao--;
            }
        }


        else if( guest.size() < tf){
            guest.add(pessoa);
            state = true;
            this.lotacao--;
            this.t--;
            getInside(pessoa);
        }

        System.out.println("Entrada de "+pessoa+" na guest -> "+state);
        System.out.println("guestlist: "+this.guest+"left:"+this.t);
        System.out.println("inscritos: "+this.inLocais+"left:"+this.lotacao);
        return fora;
    }

    public int restore_lotacao(){
        this.lotacao +=1;
        return lotacao;
    }

    public int restore_t(){
        this.t+=1;
        return t;
    }

    public List<convivioDei> getGuest() {
        return guest;
    }

    public int getTf() {
        return tf;
    }
}

/**
 * objeto do tipo jarduns
 */

class jardins extends Locais{

    private double area;

    public jardins(String nome, String gps, double area) {
        super.gps = gps;
        this.area = area;
        super.descricaoLocal = nome;
        storeLocal();
    }

    public double getArea() {
        return area;
    }

    @Override
    public List<convivioDei> getInside(convivioDei pessoa){
        super.inLocais.add(pessoa);
        System.out.println(super.inLocais);
        return super.inLocais;
    }

    @Override
    public void storeLocal(){
        fich.writeFileLocals("C:\\Users\\killz\\Desktop\\FCTUC\\2º ANO\\1º_Semestre\\POO\\ProjetoPoo\\Files\\Locais",jardins.this);
    }

}

/**
 * objeto do tipo areaDesportivo
 */

class areaDesportiva extends Locais{

    private String desporto;

    public areaDesportiva(String nome, String gps, String desporto) {
        super.gps = gps;
        this.desporto = desporto;
        super.descricaoLocal = nome;
        storeLocal();
    }

    public String getDesporto() {
        return desporto;
    }

    @Override
    public List<convivioDei> getInside(convivioDei pessoa){
        super.inLocais.add(pessoa);
        System.out.println(super.inLocais);
        return super.inLocais;
    }

    @Override
    public void storeLocal(){
        fich.writeFileLocals("C:\\Users\\killz\\Desktop\\FCTUC\\2º ANO\\1º_Semestre\\POO\\ProjetoPoo\\Files\\Locais",areaDesportiva.this);
    }

}