package com.AndreL;

import javax.swing.*;
import java.io.*;
import java.util.LinkedList;
import java.util.List;
import java.util.*;
import java.util.logging.FileHandler;

public class Main {


    public static void main(String[] args) throws IOException {

//        mainMenu menu = new mainMenu();
        GUI graficos = new GUI();

    }
}

