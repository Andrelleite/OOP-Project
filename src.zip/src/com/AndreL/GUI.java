package com.AndreL;

import jdk.nashorn.internal.scripts.JO;

import javax.imageio.ImageIO;
import javax.swing.*;
import javax.swing.border.Border;
import javax.swing.border.CompoundBorder;
import javax.swing.border.EmptyBorder;
import javax.swing.event.MenuKeyEvent;
import javax.swing.event.MenuKeyListener;
import javax.swing.plaf.ColorUIResource;
import javax.swing.plaf.basic.BasicTextFieldUI;
import javax.swing.text.JTextComponent;
import java.awt.*;
import java.awt.event.*;
import java.io.File;
import java.io.IOException;

/**
 *  INTERFACE GRAFICA
 */

public class GUI {
    ////Gestor de Dados////
    private mainMenu gestor= new mainMenu();
    private String wordpass;
    ////Frame de Inscricao///

    ////Frame de Login//////
    private JPanel img_p;
    private JLabel img;
    private JLabel t;
    private JFrame mainFrame;
    private JPanel mainPanel;
    private JTextField id;
    private JPasswordField pass;
    private JButton exit;
    private JButton Login;

    ////Frame de Inscricao////
    private JFrame logFrame;
    private JPanel logPanel;
    private JButton inscreve;
    private JLabel img_per;
    private JLabel img_pi;
    private JButton cancel;
    private JButton cont;
    private JLabel nome;
    private JLabel id_pessoa;
    private JLabel e_mail;
    private JLabel car;
    private JTextField nome_t;
    private JTextField id_t;
    private JTextField mail_t;
    private JTextField car_t;
    private JLabel perf_choose;
    private JLabel pos;
    private JComboBox perfis;
    private JComboBox pos_list;

    ////Frame Menu///////
    private JFrame frameMenu;
    private JPanel panelMenuLeft;
    private JPanel panelMenuRight;
    private JPanel panelMenu;
    private JButton show_locais;
    private JButton show_peopleByPlace;
    private JButton show_people;
    private JButton show_GuestLists;
    private JButton ch_locais;
    private JButton lucros;
    private JButton getOut;
    private JButton exit_menu;
    private JLabel imgtop;
    private JButton mu_locais;
    private JButton add_local;

    /////frame locais///////
    private JFrame placesFrame;
    private JPanel panelPlaces;
    private JPanel panelOutros;
    private JList<String> listaLocais;
    private JPanel p1;
    private JPanel p2;
    private JPanel p3;
    private JPanel p4;
    private JLabel img_5;
    private JButton retroceder;
    private JLabel warning;
    private JPopupMenu popup;
    private JComboBox tipo_local;
    private JLabel left;
    private JLabel numleft;
    private JPanel leftPanel;
    private JButton retirar;
    private JFrame frameadd;
    JMenuItem see_info;

    /////frame Inscritos//////

    private JList<String> lista_insc;
    private JList<String> listamylocais;
    private JList<String> pbp;
    private JList<String> gl;
    private JList<String> prof;


    /**
     *
     * Frames
     *
     *
     */

    protected GUI(){

        try {
            for (UIManager.LookAndFeelInfo info : UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (Exception e) {
            // If Nimbus is not available, you can set the GUI to another look and feel.
            System.out.println("shit");
        }


        /////main frame/////
        mainFrame = new JFrame();
        mainPanel = new JPanel();
        t = new JLabel("");
        exit = new JButton("Sair");
        Login = new JButton("Login");
        img = new JLabel(new ImageIcon("C:\\Users\\killz\\Desktop\\FCTUC\\2º ANO\\1º_Semestre\\POO\\ProjetoPoo\\Images\\Imagem1.png"));
        id = new JTextField("Numero UC",16);
        pass = new JPasswordField("Password",16);
        id.setPreferredSize(new Dimension(25,35));
        pass.setPreferredSize(new Dimension(25,35));
        img_p = new JPanel(new FlowLayout());

        //////Frame de inscricao//////
        logFrame = new JFrame();
        logPanel = new JPanel();
        nome = new JLabel("Nome:");
        id_pessoa = new JLabel("ID:");
        e_mail = new JLabel("Mail:");
        car = new JLabel("Info DEI:");
        pos = new JLabel("Posto no DEI:");
        perf_choose = new JLabel("Escolha um perfil:");
        cont = new JButton("Continuar");
        cancel = new JButton("Cancelar");
        img_pi = new JLabel(new ImageIcon("C:\\Users\\killz\\Desktop\\FCTUC\\2º ANO\\1º_Semestre\\POO\\ProjetoPoo\\Images\\imagem2.png"));
        img_per = new JLabel(new ImageIcon("C:\\Users\\killz\\Desktop\\FCTUC\\2º ANO\\1º_Semestre\\POO\\ProjetoPoo\\Images\\asd.png"));
        pos_list = new JComboBox();
        perfis = new JComboBox();

        /////Menu Frame////////////////
        panelMenuLeft = new JPanel();
        panelMenuRight = new JPanel();
        panelMenu = new JPanel();
        show_locais = new JButton("Ver/Escolher Locais");
        show_peopleByPlace =  new JButton("Inscritos por Local");
        show_people = new JButton("Inscritos");
        mu_locais = new JButton("Os meus Locais");
        show_GuestLists = new JButton("Ver Guest Lists");
        lucros = new JButton("Lucros do Convivio*");
        add_local = new JButton("Adicionar Locais*");
        getOut = new JButton("Desinscrever");
        exit_menu = new JButton("Sair");
        imgtop = new JLabel(new ImageIcon("C:\\Users\\killz\\Desktop\\FCTUC\\2º ANO\\1º_Semestre\\POO\\ProjetoPoo\\Images\\imagem4.png"));

        /////view places//////////////
        listaLocais = new JList<>();
        tipo_local = new JComboBox();
        listamylocais =  new JList<>();
        ////view inscritos///////////
        lista_insc = new JList<>();
        pbp = new JList<>();
        gl = new JList<>();
        prof = new JList<>();
        retirar = new JButton("Retirar");
        frameadd = new JFrame();

        MainFrame();
//        LogFrame();
//        menuFrame();

    }

    private void MainFrame() {
        mainFrame.setUndecorated(true);
        Dimension sc = Toolkit.getDefaultToolkit().getScreenSize();
        mainFrame.setLocation((sc.width-700)/2,(sc.height-600)/2);


        try {
            mainFrame.setContentPane(new JLabel(new ImageIcon(ImageIO.read(new File("C:\\Users\\killz\\Desktop\\FCTUC\\2º ANO\\1º_Semestre\\POO\\ProjetoPoo\\Images\\dei.jpg")))));
        } catch (IOException e) {
            e.printStackTrace();
        }

        mainFrame.setTitle("Convivio DEI Login");
        mainFrame.setLayout(new BorderLayout());
        mainPanel.setLayout(new GridBagLayout());
        mainFrame.setSize(750, 500);
        mainFrame.add(mainPanel,BorderLayout.EAST);
        mainPanel.setPreferredSize(new Dimension(270,600));
        mainPanel.setBackground(new Color(10,10,10,170));

        t.setFont(new Font("Arial",Font.BOLD,20));
        t.setForeground(Color.LIGHT_GRAY);


        Login.setPreferredSize(new Dimension(175,30));
        exit.setPreferredSize(new Dimension(175,30));
        Login.setBackground(new Color(15,89,237));
        Login.setForeground(Color.WHITE);
        Login.setFont(new Font("Arial",Font.BOLD,15));
        exit.setBackground(Color.RED);
        exit.setForeground(Color.WHITE);
        exit.setFont(new Font("Arial",Font.BOLD,15));

        GridBagConstraints gc = new GridBagConstraints();

        gc.gridy = 0;
        gc.gridx = 0;
        gc.weightx = 1;
        gc.weighty = 0.5;
        gc.anchor = GridBagConstraints.CENTER;
        gc.fill = GridBagConstraints.NONE;
        mainPanel.add(img,gc);

        gc.gridy = 1;
        gc.gridx = 0;
        gc.weightx = 1;
        gc.weighty = 0.1;
        gc.anchor = GridBagConstraints.CENTER;
        mainPanel.add(id,gc);

        gc.gridy = 2;
        gc.gridx = 0;
        gc.weightx = 1;
        gc.weighty = 0.5;
        gc.anchor = GridBagConstraints.CENTER;
        mainPanel.add(pass,gc);

        gc.gridy = 3;
        gc.gridx = 0;
        gc.weightx = 1;
        gc.weighty = 0.1;
        gc.anchor = GridBagConstraints.CENTER;
        mainPanel.add(Login,gc);

        gc.gridy = 4;
        gc.gridx = 0;
        gc.weightx = 1;
        gc.weighty = 0.5;
        gc.anchor = GridBagConstraints.CENTER;
        mainPanel.add(exit,gc);


        char passwordChar = pass.getEchoChar();
        pass.setEchoChar ((char) 0);
        pass.setText("Palavra Passe");

        pass.addFocusListener(new FocusListener() {
            @Override
            public void focusGained(FocusEvent e) {
                pass.setText("");
                pass.setEchoChar(passwordChar);
            }

            public void focusLost(FocusEvent e) {
                System.out.println();
            }
        });


        Login.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                String numero, passe;
                numero = id.getText();
                passe = pass.getText();

                int seletor = gestor.loginfo(numero,passe);

                if(seletor==0){
                    JOptionPane.showMessageDialog(null,"Ainda não está inscrito no Convivio. Passará para o Menu de Inscrição.");
                    wordpass = passe;
                    try{
                        gestor.atualizaData();
                    }catch (NullPointerException x){
                        System.out.println(x);
                    }                    mainFrame.dispose();
                    LogFrame();
                }else if(seletor==1){
                    JOptionPane.showMessageDialog(null,"A reencaminhar para os Menus.");

                    try{
                        gestor.atualizaData();
                    }catch (NullPointerException x){
                        System.out.println(x);
                    }

                    mainFrame.dispose();

                    menuFrame();
                }else if(seletor==-1){
                    JOptionPane.showMessageDialog(null,"ID ou Password errados. Verifique os seus dados.");
                }else{
                    JOptionPane.showMessageDialog(null,"Este ID não pertence à Comunidade do DEI");

                }
            }
        });


        exit.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                System.exit(0);
            }
        });


        mainFrame.setDefaultCloseOperation(WindowConstants.EXIT_ON_CLOSE);
        mainFrame.setResizable(false);
        mainFrame.setVisible(true);
    }

    private void LogFrame(){

        logFrame.setUndecorated(true);
        Dimension sc = Toolkit.getDefaultToolkit().getScreenSize();
        logFrame.setLocation((sc.width-700)/2,(sc.height-600)/2);

        try {
            for (UIManager.LookAndFeelInfo info : UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (Exception e) {
            // If Nimbus is not available, you can set the GUI to another look and feel.
        }


        try {
            logFrame.setContentPane(new JLabel(new ImageIcon(ImageIO.read(new File("C:\\Users\\killz\\Desktop\\FCTUC\\2º ANO\\1º_Semestre\\POO\\ProjetoPoo\\Images\\dei.jpg")))));
        } catch (IOException e) {
            e.printStackTrace();
        }

        logFrame.setTitle("Convivio DEI Login");
        logFrame.setLayout(new BorderLayout());
        logPanel.setLayout(new GridBagLayout());
        logFrame.setSize(700, 500);

        logFrame.add(logPanel,BorderLayout.EAST);
        logPanel.setPreferredSize(new Dimension(270,600));
        logPanel.setBackground(new Color(20,20,20,170));


        try{
            nome_t = new JTextField(gestor.inDei.get(0),14);
            mail_t = new JTextField(gestor.inDei.get(2),14);
            id_t = new JTextField(gestor.inDei.get(1),14);
            car_t = new JTextField(gestor.inDei.get(3),14);

        }catch(NullPointerException e){
            nome_t = new JTextField("Nome",14);
            mail_t = new JTextField("UC@uc.pt",14);
            id_t = new JTextField("Numero UC",14);
            car_t = new JTextField("Curso / Categoria / Regime",14);
        }


        nome.setFont(new Font("SansSerif Plain",Font.BOLD,15));
        nome.setForeground(Color.WHITE);
        e_mail.setFont(new Font("SansSerif Plain",Font.BOLD,15));
        e_mail.setForeground(Color.WHITE);
        id_pessoa.setFont(new Font("SansSerif Plain",Font.BOLD,15));
        id_pessoa.setForeground(Color.WHITE);
        car.setFont(new Font("SansSerif Plain",Font.BOLD,15));
        car.setForeground(Color.WHITE);
        perf_choose.setFont(new Font("SansSerif Plain",Font.BOLD,15));
        perf_choose.setForeground(Color.WHITE);
        pos.setFont(new Font("SansSerif Plain",Font.BOLD,15));
        pos.setForeground(Color.WHITE);

        cont.setPreferredSize(new Dimension(90,35));
        cancel.setPreferredSize(new Dimension(90,35));
        cont.setBackground(new Color(15,89,237));
        cancel.setBackground(Color.RED);
        cont.setForeground(Color.WHITE);
        cancel.setForeground(Color.WHITE);




        DefaultComboBoxModel p_model = new DefaultComboBoxModel();
        p_model.addElement("Boemio");
        p_model.addElement("Poupadinho");
        p_model.addElement("Desportivo");
        p_model.addElement("Cultural");
        perfis.setModel(p_model);
        perfis.setPreferredSize(new Dimension(120,35));


        DefaultComboBoxModel pos_model = new DefaultComboBoxModel();
        pos_model.addElement("Professor");
        pos_model.addElement("Aluno");
        pos_model.addElement("Auxiliar");
        pos_list.setModel(pos_model);
        pos_list.setPreferredSize(new Dimension(120,35));

        GridBagConstraints gc = new GridBagConstraints();

        ///////////// left panel ///////////////////////////////////

        gc.gridx = 1;
        gc.gridy = 0;
        gc.insets = new Insets(0,10,0,0);
        gc.anchor = GridBagConstraints.LINE_START;
        logPanel.add(img_pi,gc);


        ///////////// right panel ///////////////////////////////////

        gc.gridx = 1;
        gc.gridy = 1;
        gc.insets = new Insets(0,10,10,0);
        gc.anchor = GridBagConstraints.CENTER;
        logPanel.add(img_per,gc);

        gc.gridx = 0;
        gc.gridy = 2;
        gc.gridwidth = 10;
        gc.insets = new Insets(0,10,5,0);
        gc.anchor = GridBagConstraints.LINE_START;
        logPanel.add(nome,gc);

        gc.gridx = 1;
        gc.gridy = 2;
        gc.gridwidth = 10;
        gc.weightx = 20;
        gc.insets = new Insets(0,10,5,6);
        gc.anchor = GridBagConstraints.LINE_END;
        logPanel.add(nome_t,gc);

        gc.gridx = 0;
        gc.gridy = 3;
        gc.gridwidth = 10;
        gc.insets = new Insets(0,10,5,0);
        gc.anchor = GridBagConstraints.LINE_START;
        logPanel.add(id_pessoa,gc);

        gc.gridx = 1;
        gc.gridy = 3;
        gc.gridwidth = 10;
        gc.weightx = 20;
        gc.insets = new Insets(0,10,5,6);
        gc.anchor = GridBagConstraints.LINE_END;
        logPanel.add(id_t,gc);

        gc.gridx = 0;
        gc.gridy = 4;
        gc.gridwidth = 10;
        gc.insets = new Insets(0,10,5,0);
        gc.anchor = GridBagConstraints.LINE_START;
        logPanel.add(e_mail,gc);

        gc.gridx = 1;
        gc.gridy = 4;
        gc.gridwidth = 10;
        gc.weightx = 20;
        gc.insets = new Insets(0,10,5,6);
        gc.anchor = GridBagConstraints.LINE_END;
        logPanel.add(mail_t,gc);

        gc.gridx = 0;
        gc.gridy = 5;
        gc.gridwidth = 10;
        gc.insets = new Insets(0,10,5,0);
        gc.anchor = GridBagConstraints.LINE_START;
        logPanel.add(car,gc);

        gc.gridx = 1;
        gc.gridy = 5;
        gc.gridwidth = 10;
        gc.weightx = 20;
        gc.insets = new Insets(0,10,5,6);
        gc.anchor = GridBagConstraints.LINE_END;
        logPanel.add(car_t,gc);

        gc.gridx = 0;
        gc.gridy = 6;
        gc.gridwidth = 10;
        gc.weightx = 20;
        gc.insets = new Insets(0,10,5,6);
        gc.anchor = GridBagConstraints.LINE_START;
        logPanel.add(pos,gc);

        gc.gridx = 1;
        gc.gridy = 6;
        gc.gridwidth = 10;
        gc.weightx = 20;
        gc.insets = new Insets(0,10,5,6);
        gc.anchor = GridBagConstraints.EAST;
        logPanel.add(pos_list,gc);

        gc.gridx = 0;
        gc.gridy = 7;
        gc.gridwidth = 10;
        gc.weightx = 20;
        gc.insets = new Insets(0,10,15,6);
        gc.anchor = GridBagConstraints.LINE_START;
        logPanel.add(perf_choose,gc);

        gc.gridx = 1;
        gc.gridy = 7;
        gc.gridwidth = 10;
        gc.weightx = 20;
        gc.insets = new Insets(0,10,15,6);
        gc.anchor = GridBagConstraints.EAST;
        logPanel.add(perfis,gc);

        gc.gridx = 0;
        gc.gridy = 8;
        gc.gridwidth = 5;
        gc.insets = new Insets(0,10,0,0);
        gc.anchor = GridBagConstraints.LINE_START;
        logPanel.add(cont,gc);


        gc.gridx = 1;
        gc.gridy = 8;
        gc.gridwidth = 5;
        gc.insets = new Insets(0,0,0,10);
        gc.anchor = GridBagConstraints.LINE_END;
        logPanel.add(cancel,gc);


        cancel.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                System.exit(0);
            }
        });

        cont.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                String get_perfil = perfis.getSelectedItem().toString();
                System.out.println(get_perfil);
                String get_pos = pos_list.getSelectedItem().toString();
                System.out.println(get_pos);
                gestor.getIn(gestor.inDei.get(0),gestor.inDei.get(1),gestor.inDei.get(2),gestor.inDei.get(3),wordpass,get_pos,get_perfil);
                JOptionPane.showMessageDialog(null,"Foi inscrito no Convivio do DEI.");
                logFrame.dispose();
                view_palces();
            }
        });



        logFrame.setDefaultCloseOperation(WindowConstants.EXIT_ON_CLOSE);
        logFrame.setResizable(false);
        logFrame.setVisible(true);


    }

    private void menuFrame(){
        frameMenu = new JFrame();

        frameMenu.setUndecorated(true);

        Dimension sc = Toolkit.getDefaultToolkit().getScreenSize();
        frameMenu.setLocation((sc.width-850)/2,(sc.height-620)/2);

        try {
            frameMenu.setContentPane(new JLabel(new ImageIcon(ImageIO.read(new File("C:\\Users\\killz\\Desktop\\FCTUC\\2º ANO\\1º_Semestre\\POO\\ProjetoPoo\\Images\\dei.png")))));
        } catch (IOException e) {
            e.printStackTrace();
        }

        frameMenu.setLayout(new BorderLayout());
        panelMenu.setLayout(new GridBagLayout());
        frameMenu.setSize(850, 620);

        frameMenu.add(panelMenuLeft,BorderLayout.WEST);
        panelMenuLeft.setPreferredSize(new Dimension(250,600));
        panelMenuLeft.setBackground(new Color(20,111,20,0));

        frameMenu.add(panelMenuRight,BorderLayout.EAST);
        panelMenuRight.setPreferredSize(new Dimension(250,600));
        panelMenuRight.setBackground(new Color(200,111,20,0));

        frameMenu.add(panelMenu,BorderLayout.CENTER);
        panelMenu.setPreferredSize(new Dimension(300,500));
        panelMenu.setBackground(new Color(20,20,20,200));


        show_locais.setPreferredSize(new Dimension(200,35));
        show_peopleByPlace.setPreferredSize(new Dimension(200,35));
        mu_locais.setPreferredSize(new Dimension(200,35));
        show_people.setPreferredSize(new Dimension(200,35));
        show_GuestLists.setPreferredSize(new Dimension(200,35));
        lucros.setPreferredSize(new Dimension(200,35));
        add_local.setPreferredSize(new Dimension(200,35));
        getOut.setPreferredSize(new Dimension(200,35));
        exit_menu.setPreferredSize(new Dimension(200,35));

        show_locais.setFont(new Font("SansSerif Plain",Font.BOLD,15));
        show_people.setFont(new Font("SansSerif Plain",Font.BOLD,15));
        show_peopleByPlace.setFont(new Font("SansSerif Plain",Font.BOLD,15));
        show_GuestLists.setFont(new Font("SansSerif Plain",Font.BOLD,15));
        lucros.setFont(new Font("SansSerif Plain",Font.BOLD,15));
        getOut.setFont(new Font("SansSerif Plain",Font.BOLD,15));
        add_local.setFont(new Font("SansSerif Plain",Font.BOLD,15));
        exit_menu.setFont(new Font("SansSerif Plain",Font.BOLD,15));
        mu_locais.setFont(new Font("SansSerif Plain",Font.BOLD,15));


        show_locais.setBackground(Color.WHITE);
        show_peopleByPlace.setBackground(Color.WHITE);
        show_people.setBackground(Color.WHITE);
        show_GuestLists.setBackground(Color.WHITE);
        lucros.setBackground(Color.GREEN);
        lucros.setForeground(Color.BLACK);
        getOut.setBackground(Color.WHITE);
        mu_locais.setBackground(Color.WHITE);
        add_local.setBackground(Color.GREEN );
        add_local.setForeground(Color.BLACK);
        exit_menu.setBackground(Color.RED);
        exit_menu.setForeground(Color.WHITE);

        GridBagConstraints gc = new GridBagConstraints();


        gc.gridx = 0;
        gc.gridy = 0;
        gc.anchor = GridBagConstraints.CENTER;
        gc.insets = new Insets(0,0,0,0);
        panelMenu.add(imgtop,gc);

        gc.gridx = 0;
        gc.gridy = 1;
        gc.insets = new Insets(5,0,5,0);
        gc.anchor = GridBagConstraints.CENTER;
        panelMenu.add(show_locais,gc);

        gc.gridx = 0;
        gc.gridy = 2;
        gc.insets = new Insets(5,0,5,0);
        gc.anchor = GridBagConstraints.CENTER;
        panelMenu.add(mu_locais,gc);

        gc.gridx = 0;
        gc.gridy = 3;
        gc.insets = new Insets(5,0,5,0);
        gc.anchor = GridBagConstraints.CENTER;
        panelMenu.add(show_people,gc);

        gc.gridx = 0;
        gc.gridy = 4;
        gc.insets = new Insets(5,0,5,0);
        gc.anchor = GridBagConstraints.CENTER;
        panelMenu.add(show_peopleByPlace,gc);

        gc.gridx = 0;
        gc.gridy = 5;
        gc.insets = new Insets(5,0,5,0);
        gc.anchor = GridBagConstraints.CENTER;
        panelMenu.add(show_GuestLists,gc);

        gc.gridx = 0;
        gc.gridy = 6;
        gc.anchor = GridBagConstraints.CENTER;
        gc.insets = new Insets(5,10,5,10);
        panelMenu.add(getOut,gc);

        gc.gridx = 0;
        gc.gridy = 7;
        gc.anchor = GridBagConstraints.CENTER;
        gc.insets = new Insets(5,10,5,10);
        panelMenu.add(add_local,gc);

        gc.gridx = 0;
        gc.gridy = 8;
        gc.anchor = GridBagConstraints.CENTER;
        gc.insets = new Insets(5,10,5,10);
        panelMenu.add(lucros,gc);

        gc.gridx = 0;
        gc.gridy = 9;
        gc.anchor = GridBagConstraints.CENTER;
        gc.insets = new Insets(5,10,0,10);
        panelMenu.add(exit_menu,gc);

        getOut.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                int dialogResult = JOptionPane.showConfirmDialog(null,"Deseja desinscrever-se do convívio?");
                if(dialogResult == JOptionPane.YES_OPTION){
                    gestor.desinscreve();
                    System.exit(0);
                }
            }
        });

        show_locais.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                frameMenu.dispose();
                view_palces();
            }
        });

        show_people.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                frameMenu.dispose();
                view_insc();
            }
        });

        mu_locais.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                frameMenu.dispose();
                local_inscritos();
            }
        });

        exit_menu.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                gestor.atualizaData();
                System.exit(0);
            }
        });

        show_peopleByPlace.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                frameMenu.dispose();
                people_by_place();
            }
        });

        show_GuestLists.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                frameMenu.dispose();
                guest_people();
            }
        });

        lucros.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {

                String entered_pass = "";
                entered_pass = JOptionPane.showInputDialog("Introduza a password de Admin:");
                try{
                    if(entered_pass.equals("admin")) {
                        frameMenu.dispose();
                        ver_profit();
                    }
                }catch (NullPointerException w){
                    w.fillInStackTrace();
                }

            }
        });

        add_local.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {

                String entered_pass = "";
                entered_pass = JOptionPane.showInputDialog("Introduza a password de Admin:");
                try{
                    if(entered_pass.equals("admin")) {
                        JOptionPane.showMessageDialog(null,"Nao disponivel.");
                    }
                }catch (NullPointerException w){
                    w.fillInStackTrace();
                }

            }
        });

        frameMenu.setDefaultCloseOperation(WindowConstants.EXIT_ON_CLOSE);
        frameMenu.setResizable(false);
        frameMenu.setVisible(true);

    }

    private void view_palces(){

        this.frameMenu = new JFrame();
        panelPlaces = new JPanel();
        p1 = new JPanel();
        p2 = new JPanel();
        p3 = new JPanel();
        p4 = new JPanel();
        p4.setLayout(new GridBagLayout());
        this.panelOutros = new JPanel();
        img_5 = new JLabel(new ImageIcon("C:\\Users\\killz\\Desktop\\FCTUC\\2º ANO\\1º_Semestre\\POO\\ProjetoPoo\\Images\\imagem5.png"));
        warning = new JLabel("* Se clicar no local poderá aceder à sua informação.");
        this.frameMenu.setUndecorated(true);
        JButton choose = new JButton("Selecionar");
        choose.setBackground(Color.GREEN);
        choose.setForeground(Color.BLACK);
        choose.setFont(new Font("Sans Serif",Font.BOLD,15));
        choose.setPreferredSize(new Dimension(250,100));

        retirar.setBackground(Color.RED);
        retirar.setForeground(Color.white);
        retirar.setFont(new Font("Sans Serif",Font.BOLD,15));
        retirar.setPreferredSize(new Dimension(250,100));

        leftPanel = new JPanel(new FlowLayout());
        leftPanel.setBackground(new Color(0,0,0,0));
        left = new JLabel("Por escolher:");
        left.setFont(new Font("Sans Serif",Font.BOLD,18));
        left.setForeground(Color.BLACK);
        numleft = new JLabel(new Integer(5 - gestor.getNovo().going.size()).toString());
        numleft.setFont(new Font("Sans Serif", Font.BOLD,25));
        numleft.setForeground(Color.BLACK);

        Dimension sc = Toolkit.getDefaultToolkit().getScreenSize();
        this.frameMenu.setLocation((sc.width-850)/2,(sc.height-620)/2);

        try {
            this.frameMenu.setContentPane(new JLabel(new ImageIcon(ImageIO.read(new File("C:\\Users\\killz\\Desktop\\FCTUC\\2º ANO\\1º_Semestre\\POO\\ProjetoPoo\\Images\\dei.png")))));
        } catch (IOException e) {
            e.printStackTrace();
        }

        DefaultComboBoxModel modelo = new DefaultComboBoxModel();
        modelo.addElement("Todos");
        modelo.addElement("Exposicoes");
        modelo.addElement("Areas Desportivas");
        modelo.addElement("Jardins");
        modelo.addElement("Bares");
        tipo_local.setModel(modelo);
        tipo_local.setPreferredSize(new Dimension(120,35));

        this.frameMenu.setLayout(new BorderLayout());
        this.panelPlaces.setLayout(new BorderLayout());
        this.frameMenu.setSize(850, 620);

        this.frameMenu.add(p2,BorderLayout.NORTH);
        p2.setPreferredSize(new Dimension(100,150));
        p2.setBackground(new Color(20,200,20,0));
        p2.setLayout(new BorderLayout());
        p2.add(img_5,BorderLayout.SOUTH);

        this.frameMenu.add(p1,BorderLayout.SOUTH);
        p1.setPreferredSize(new Dimension(100,150));
        p1.setBackground(new Color(20,200,20,0));
        p1.setLayout(new GridBagLayout());

        warning.setFont(new Font("Sans Serif",Font.BOLD,15));
        warning.setForeground(Color.black);

        retroceder = new JButton("Voltar ao menu");
        retroceder.setBackground(Color.RED);
        retroceder.setForeground(Color.WHITE);
        retroceder.setFont(new Font("Sans Serif",Font.BOLD,15));
        retroceder.setPreferredSize(new Dimension(250,100));

        GridBagConstraints gc = new GridBagConstraints();

        gc.gridx = 0;
        gc.gridy = 0;
        gc.anchor = GridBagConstraints.LINE_START;
        gc.insets = new Insets(0,150,50,0);
        p1.add(warning,gc);

        gc.gridy = 1;
        gc.gridx = 2;
        gc.ipady = 10;
        gc.ipadx = 30;
        gc.anchor = GridBagConstraints.CENTER;
        gc.insets = new Insets(10,20,15,50);
        p1.add(retroceder,gc);

        gc.gridy = 1;
        gc.gridx = 1;
        gc.ipady = 10;
        gc.ipadx = 30;
        gc.anchor = GridBagConstraints.CENTER;
        gc.insets = new Insets(10,20,15,50);
        p1.add(retirar,gc);

        gc.gridy = 1;
        gc.gridx = 0;
        gc.ipady = 10;
        gc.ipadx = 30;
        gc.anchor = GridBagConstraints.CENTER;
        gc.insets = new Insets(10,100,15,0);
        p1.add(choose,gc);


        this.frameMenu.add(p3,BorderLayout.EAST);
        p3.setPreferredSize(new Dimension(10,150));
        p3.setBackground(new Color(20,200,20,0));

        this.frameMenu.add(p4,BorderLayout.WEST);
        p4.setPreferredSize(new Dimension(200,150));
        p4.setBackground(new Color(20,200,20,0));

        gc.gridy = 0;
        gc.gridx = 0;
        gc.ipady = 20;
        gc.insets = new Insets(50,20,0,20);
        gc.anchor = GridBagConstraints.CENTER;
        p4.add(tipo_local,gc);

        gc.gridy = 1;
        gc.gridx = 0;
        gc.ipady = 20;
        gc.insets = new Insets(60,15,0,20);
        gc.anchor = GridBagConstraints.CENTER;
        p4.add(leftPanel,gc);

        leftPanel.add(left);
        leftPanel.add(numleft);


        this.frameMenu.add(panelPlaces,BorderLayout.CENTER);
        panelPlaces.setPreferredSize(new Dimension(650,500));
        panelPlaces.setBackground(new Color(20,20,20,200));

        listaLocais.setPreferredSize(new Dimension(300,350));
        listaLocais.setFixedCellWidth(600);
        listaLocais.setFixedCellHeight(30);
        listaLocais.setFont(new Font("Sans Serif",Font.BOLD,18));
        listaLocais.setBorder(BorderFactory.createEtchedBorder());

        tipo_local.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                String local_tip = tipo_local.getSelectedItem().toString();
                locais(local_tip);
            }
        });

        JScrollPane scroll = new JScrollPane(listaLocais, JScrollPane.VERTICAL_SCROLLBAR_AS_NEEDED, JScrollPane.HORIZONTAL_SCROLLBAR_NEVER);

        retirar.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                int ind = listaLocais.getSelectedIndex();
                int res = gestor.removeLocal(ind);

                if(res == 1){
                    JOptionPane.showMessageDialog(null, "Retirou o local da sua lista, com sucesso!");
                    locais("todos");
                }
                else{
                    JOptionPane.showMessageDialog(null,"Este Local não foi selecionado por si.");
                }

            }
        });


        retroceder.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                frameMenu.dispose();
                menuFrame();
            }
        });

        locais("todos");

        listaLocais.addMouseListener(new MouseAdapter() {
            public void mouseClicked(MouseEvent me) {
                if (SwingUtilities.isLeftMouseButton(me)
                        && !listaLocais.isSelectionEmpty()
                        && listaLocais.locationToIndex(me.getPoint())
                        == listaLocais.getSelectedIndex()) {
                    popup = new JPopupMenu();
                    locais_info(listaLocais.getSelectedIndex());
                    popup.show(listaLocais, me.getX(), me.getY());
                }
            }
        });

        choose.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {

                if(5 - gestor.getNovo().going.size() <= 5 && 5 - gestor.getNovo().going.size() > 0){
                    int indice = listaLocais.getSelectedIndex();
                    int resposta = gestor.selectPlaces(indice);

                    if(resposta == 1){
                        JOptionPane.showMessageDialog(null,"O local onde deseja inscrever-se está cheio.");
                    }else if(resposta == 2 || resposta == 3){
                        JOptionPane.showMessageDialog(null,"Já está inscrito neste local.");
                    }

                }else if(5 - gestor.getNovo().going.size() <= 0){
                    JOptionPane.showConfirmDialog(null,"Já atingiu o limite de locais possiveis escolher.");
                    numleft.setForeground(Color.RED);
                }
                numleft.setText(new Integer(5 - gestor.getNovo().going.size()).toString());
                locais("todos");

            }
        });

        panelPlaces.add(scroll,BorderLayout.CENTER);

        this.frameMenu.setDefaultCloseOperation(WindowConstants.EXIT_ON_CLOSE);
        this.frameMenu.setVisible(true);


    }

    private void view_insc(){

        this.frameMenu = new JFrame();
        panelPlaces = new JPanel();
        p1 = new JPanel();
        p2 = new JPanel();
        p3 = new JPanel();
        p4 = new JPanel();
        p4.setLayout(new GridBagLayout());
        this.panelOutros = new JPanel();
        img_5 = new JLabel(new ImageIcon("C:\\Users\\killz\\Desktop\\FCTUC\\2º ANO\\1º_Semestre\\POO\\ProjetoPoo\\Images\\imagem6.png"));
        this.frameMenu.setUndecorated(true);

        Dimension sc = Toolkit.getDefaultToolkit().getScreenSize();
        this.frameMenu.setLocation((sc.width-850)/2,(sc.height-620)/2);

        try {
            this.frameMenu.setContentPane(new JLabel(new ImageIcon(ImageIO.read(new File("C:\\Users\\killz\\Desktop\\FCTUC\\2º ANO\\1º_Semestre\\POO\\ProjetoPoo\\Images\\dei.png")))));
        } catch (IOException e) {
            e.printStackTrace();
        }

        DefaultComboBoxModel modelo = new DefaultComboBoxModel();
        modelo.addElement("Todos");
        modelo.addElement("Alunos");
        modelo.addElement("Professores");
        modelo.addElement("Auxiliares");
        tipo_local.setModel(modelo);
        tipo_local.setPreferredSize(new Dimension(120,35));

        this.frameMenu.setLayout(new BorderLayout());
        this.panelPlaces.setLayout(new BorderLayout());
        this.frameMenu.setSize(850, 620);

        this.frameMenu.add(p2,BorderLayout.NORTH);
        p2.setPreferredSize(new Dimension(100,150));
        p2.setBackground(new Color(20,200,20,0));
        p2.setLayout(new BorderLayout());
        p2.add(img_5,BorderLayout.SOUTH);

        this.frameMenu.add(p1,BorderLayout.SOUTH);
        p1.setPreferredSize(new Dimension(100,150));
        p1.setBackground(new Color(20,200,20,0));
        p1.setLayout(new GridBagLayout());

        retroceder = new JButton("Voltar ao menu");
        retroceder.setBackground(Color.RED);
        retroceder.setForeground(Color.WHITE);
        retroceder.setFont(new Font("Sans Serif",Font.BOLD,15));
        retroceder.setPreferredSize(new Dimension(150,30));

        GridBagConstraints gc = new GridBagConstraints();

        gc.gridx = 0;
        gc.gridy = 0;
        gc.anchor = GridBagConstraints.LINE_START;
        gc.insets = new Insets(0,0,50,270);

        gc.gridy = 1;
        gc.gridx = 0;
        gc.ipady = 20;
        gc.ipadx = 20;
        gc.anchor = GridBagConstraints.CENTER;
        gc.insets = new Insets(10,0,15,0);
        p1.add(retroceder,gc);

        this.frameMenu.add(p3,BorderLayout.EAST);
        p3.setPreferredSize(new Dimension(10,150));
        p3.setBackground(new Color(20,200,20,0));

        this.frameMenu.add(p4,BorderLayout.WEST);
        p4.setPreferredSize(new Dimension(200,150));
        p4.setBackground(new Color(20,200,20,0));
        gc.gridy = 0;
        gc.gridx = 0;
        gc.ipady = 20;
        gc.anchor = GridBagConstraints.CENTER;
        p4.add(tipo_local,gc);

        this.frameMenu.add(panelPlaces,BorderLayout.CENTER);
        panelPlaces.setPreferredSize(new Dimension(650,500));
        panelPlaces.setBackground(new Color(20,20,20,200));

        lista_insc.setPreferredSize(new Dimension(300,350));
        lista_insc.setFixedCellWidth(600);
        lista_insc.setFixedCellHeight(30);
        lista_insc.setFont(new Font("Sans Serif",Font.BOLD,16));
        lista_insc.setBorder(BorderFactory.createEtchedBorder());

        inscritos("todos");

        tipo_local.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                String local_tip = tipo_local.getSelectedItem().toString();
                inscritos(local_tip);
            }
        });

        JScrollPane scroll = new JScrollPane(lista_insc, JScrollPane.VERTICAL_SCROLLBAR_AS_NEEDED, JScrollPane.HORIZONTAL_SCROLLBAR_NEVER);

        retroceder.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                frameMenu.dispose();
                menuFrame();
            }
        });


        panelPlaces.add(scroll,BorderLayout.CENTER);

        this.frameMenu.setDefaultCloseOperation(WindowConstants.EXIT_ON_CLOSE);
        this.frameMenu.setVisible(true);

    }

    private void local_inscritos(){

        this.frameMenu = new JFrame();
        panelPlaces = new JPanel();
        p1 = new JPanel();
        p2 = new JPanel();
        p3 = new JPanel();
        p4 = new JPanel();
        p4.setLayout(new GridBagLayout());
        this.panelOutros = new JPanel();
        img_5 = new JLabel("                            Locais escolhidos por: "+gestor.getNovo().nome);
        img_5.setFont(new Font("Sans Serif",Font.BOLD,25));
        this.frameMenu.setUndecorated(true);

        Dimension sc = Toolkit.getDefaultToolkit().getScreenSize();
        this.frameMenu.setLocation((sc.width-850)/2,(sc.height-620)/2);

        try {
            this.frameMenu.setContentPane(new JLabel(new ImageIcon(ImageIO.read(new File("C:\\Users\\killz\\Desktop\\FCTUC\\2º ANO\\1º_Semestre\\POO\\ProjetoPoo\\Images\\dei.png")))));
        } catch (IOException e) {
            e.printStackTrace();
        }

        DefaultComboBoxModel modelo = new DefaultComboBoxModel();
        modelo.addElement("Todos");
        modelo.addElement("Exposicoes");
        modelo.addElement("Areas Desportivas");
        modelo.addElement("Jardins");
        modelo.addElement("Bares");
        tipo_local.setModel(modelo);
        tipo_local.setPreferredSize(new Dimension(120,35));

        this.frameMenu.setLayout(new BorderLayout());
        this.panelPlaces.setLayout(new BorderLayout());
        this.frameMenu.setSize(850, 620);

        this.frameMenu.add(p2,BorderLayout.NORTH);
        p2.setPreferredSize(new Dimension(100,150));
        p2.setBackground(new Color(20,200,20,0));
        p2.setLayout(new BorderLayout());
        p2.add(img_5,BorderLayout.SOUTH);

        this.frameMenu.add(p1,BorderLayout.SOUTH);
        p1.setPreferredSize(new Dimension(100,150));
        p1.setBackground(new Color(20,200,20,0));
        p1.setLayout(new GridBagLayout());

        retroceder = new JButton("Voltar ao menu");
        retroceder.setBackground(Color.RED);
        retroceder.setForeground(Color.WHITE);
        retroceder.setFont(new Font("Sans Serif",Font.BOLD,15));
        retroceder.setPreferredSize(new Dimension(150,50));

        GridBagConstraints gc = new GridBagConstraints();

        gc.gridy = 1;
        gc.gridx = 1;
        gc.ipady = 20;
        gc.ipadx = 60;
        gc.anchor = GridBagConstraints.CENTER;
        gc.insets = new Insets(10,0,15,50);
        p1.add(retroceder,gc);

        this.frameMenu.add(p3,BorderLayout.EAST);
        p3.setPreferredSize(new Dimension(10,150));
        p3.setBackground(new Color(20,200,20,0));

        this.frameMenu.add(p4,BorderLayout.WEST);
        p4.setPreferredSize(new Dimension(200,150));
        p4.setBackground(new Color(20,200,20,0));
        gc.gridy = 0;
        gc.gridx = 0;
        gc.ipady = 20;
        gc.insets = new Insets(0,0,0,20);
        gc.anchor = GridBagConstraints.CENTER;
        p4.add(tipo_local,gc);

        this.frameMenu.add(panelPlaces,BorderLayout.CENTER);
        panelPlaces.setPreferredSize(new Dimension(650,500));
        panelPlaces.setBackground(new Color(20,20,20,200));

        listamylocais.setPreferredSize(new Dimension(300,350));
        listamylocais.setFixedCellWidth(600);
        listamylocais.setFixedCellHeight(30);
        listamylocais.setFont(new Font("Sans Serif",Font.BOLD,18));
        listamylocais.setBorder(BorderFactory.createEtchedBorder());

        JScrollPane scroll = new JScrollPane(listamylocais, JScrollPane.VERTICAL_SCROLLBAR_AS_NEEDED, JScrollPane.HORIZONTAL_SCROLLBAR_NEVER);

        retroceder.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                frameMenu.dispose();
                menuFrame();
            }
        });

        my_locais("todos");

        tipo_local.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                String c = tipo_local.getSelectedItem().toString();
                my_locais(c);
            }
        });


        panelPlaces.add(scroll,BorderLayout.CENTER);

        this.frameMenu.setDefaultCloseOperation(WindowConstants.EXIT_ON_CLOSE);
        this.frameMenu.setVisible(true);


    }

    private void people_by_place(){

        this.frameMenu = new JFrame();
        panelPlaces = new JPanel();
        p1 = new JPanel();
        p2 = new JPanel();
        p3 = new JPanel();
        p4 = new JPanel();
        p4.setLayout(new GridBagLayout());
        this.panelOutros = new JPanel();
        img_5 = new JLabel("                            Inscritos por locais: ");
        img_5.setFont(new Font("Sans Serif",Font.BOLD,25));
        this.frameMenu.setUndecorated(true);

        Dimension sc = Toolkit.getDefaultToolkit().getScreenSize();
        this.frameMenu.setLocation((sc.width-850)/2,(sc.height-620)/2);

        try {
            this.frameMenu.setContentPane(new JLabel(new ImageIcon(ImageIO.read(new File("C:\\Users\\killz\\Desktop\\FCTUC\\2º ANO\\1º_Semestre\\POO\\ProjetoPoo\\Images\\dei.png")))));
        } catch (IOException e) {
            e.printStackTrace();
        }

        DefaultComboBoxModel modelo = new DefaultComboBoxModel();
        modelo.addElement("Todos");
        modelo.addElement("Exposicoes");
        modelo.addElement("Areas Desportivas");
        modelo.addElement("Jardins");
        modelo.addElement("Bares");
        tipo_local.setModel(modelo);
        tipo_local.setPreferredSize(new Dimension(120,35));

        this.frameMenu.setLayout(new BorderLayout());
        this.panelPlaces.setLayout(new BorderLayout());
        this.frameMenu.setSize(850, 620);

        this.frameMenu.add(p2,BorderLayout.NORTH);
        p2.setPreferredSize(new Dimension(100,150));
        p2.setBackground(new Color(20,200,20,0));
        p2.setLayout(new BorderLayout());
        p2.add(img_5,BorderLayout.SOUTH);

        this.frameMenu.add(p1,BorderLayout.SOUTH);
        p1.setPreferredSize(new Dimension(100,150));
        p1.setBackground(new Color(20,200,20,0));
        p1.setLayout(new GridBagLayout());

        retroceder = new JButton("Voltar ao menu");
        retroceder.setBackground(Color.RED);
        retroceder.setForeground(Color.WHITE);
        retroceder.setFont(new Font("Sans Serif",Font.BOLD,15));
        retroceder.setPreferredSize(new Dimension(150,50));

        GridBagConstraints gc = new GridBagConstraints();

        gc.gridy = 1;
        gc.gridx = 1;
        gc.ipady = 20;
        gc.ipadx = 60;
        gc.anchor = GridBagConstraints.CENTER;
        gc.insets = new Insets(10,0,15,50);
        p1.add(retroceder,gc);

        this.frameMenu.add(p3,BorderLayout.EAST);
        p3.setPreferredSize(new Dimension(10,150));
        p3.setBackground(new Color(20,200,20,0));

        this.frameMenu.add(p4,BorderLayout.WEST);
        p4.setPreferredSize(new Dimension(200,150));
        p4.setBackground(new Color(20,200,20,0));
        gc.gridy = 0;
        gc.gridx = 0;
        gc.ipady = 20;
        gc.insets = new Insets(0,0,0,20);
        gc.anchor = GridBagConstraints.CENTER;
        p4.add(tipo_local,gc);

        this.frameMenu.add(panelPlaces,BorderLayout.CENTER);
        panelPlaces.setPreferredSize(new Dimension(650,550));
        panelPlaces.setBackground(new Color(20,20,20,200));

        pbp.setPreferredSize(new Dimension(300,350));
        pbp.setFixedCellWidth(600);
        pbp.setFixedCellHeight(30);
        pbp.setFont(new Font("Sans Serif",Font.BOLD,12));
//        pbp.setBorder(BorderFactory.createEtchedBorder());

        JScrollPane scroll = new JScrollPane(pbp, JScrollPane.VERTICAL_SCROLLBAR_ALWAYS, JScrollPane.HORIZONTAL_SCROLLBAR_NEVER);

        retroceder.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                frameMenu.dispose();
                menuFrame();
            }
        });

        p_by_p("todos");

        tipo_local.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                String c = tipo_local.getSelectedItem().toString();
                p_by_p(c);
            }
        });


        panelPlaces.add(scroll,BorderLayout.CENTER);

        this.frameMenu.setDefaultCloseOperation(WindowConstants.EXIT_ON_CLOSE);
        this.frameMenu.setVisible(true);

    }

    private void guest_people(){

        this.frameMenu = new JFrame();
        panelPlaces = new JPanel();
        p1 = new JPanel();
        p2 = new JPanel();
        p3 = new JPanel();
        p4 = new JPanel();
        p4.setLayout(new GridBagLayout());
        this.panelOutros = new JPanel();
        img_5 = new JLabel("                Guest Lists: ");
        img_5.setFont(new Font("Sans Serif",Font.BOLD,25));
        this.frameMenu.setUndecorated(true);

        Dimension sc = Toolkit.getDefaultToolkit().getScreenSize();
        this.frameMenu.setLocation((sc.width-850)/2,(sc.height-620)/2);

        try {
            this.frameMenu.setContentPane(new JLabel(new ImageIcon(ImageIO.read(new File("C:\\Users\\killz\\Desktop\\FCTUC\\2º ANO\\1º_Semestre\\POO\\ProjetoPoo\\Images\\dei.png")))));
        } catch (IOException e) {
            e.printStackTrace();
        }

        this.frameMenu.setLayout(new BorderLayout());
        this.panelPlaces.setLayout(new BorderLayout());
        this.frameMenu.setSize(850, 620);

        this.frameMenu.add(p2,BorderLayout.NORTH);
        p2.setPreferredSize(new Dimension(100,70));
        p2.setBackground(new Color(20,200,20,0));
        p2.setLayout(new BorderLayout());
        p2.add(img_5,BorderLayout.SOUTH);

        this.frameMenu.add(p1,BorderLayout.SOUTH);
        p1.setPreferredSize(new Dimension(100,100));
        p1.setBackground(new Color(20,200,20,0));
        p1.setLayout(new GridBagLayout());

        retroceder = new JButton("Voltar ao menu");
        retroceder.setBackground(Color.RED);
        retroceder.setForeground(Color.WHITE);
        retroceder.setFont(new Font("Sans Serif",Font.BOLD,15));
        retroceder.setPreferredSize(new Dimension(100,50));

        GridBagConstraints gc = new GridBagConstraints();

        gc.gridy = 1;
        gc.gridx = 1;
        gc.ipady = 20;
        gc.ipadx = 60;
        gc.anchor = GridBagConstraints.CENTER;
        gc.insets = new Insets(10,0,15,50);
        p1.add(retroceder,gc);

        this.frameMenu.add(p3,BorderLayout.EAST);
        p3.setPreferredSize(new Dimension(10,150));
        p3.setBackground(new Color(20,200,20,0));

        this.frameMenu.add(panelPlaces,BorderLayout.CENTER);
        panelPlaces.setPreferredSize(new Dimension(500,650));
        panelPlaces.setBackground(new Color(20,20,20,200));

        gl.setPreferredSize(new Dimension(400,350));
        gl.setFixedCellWidth(500);
        gl.setFixedCellHeight(20);
        gl.setFont(new Font("Sans Serif",Font.BOLD,18));
        gl.setBorder(BorderFactory.createEtchedBorder());

        JScrollPane scroll = new JScrollPane(gl);


        retroceder.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                frameMenu.dispose();
                menuFrame();
            }
        });

        guests();

        tipo_local.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                String c = tipo_local.getSelectedItem().toString();
                guests();
            }
        });


        panelPlaces.add(scroll,BorderLayout.CENTER);

        this.frameMenu.setDefaultCloseOperation(WindowConstants.EXIT_ON_CLOSE);
        this.frameMenu.setVisible(true);

    }

    private void ver_profit(){

        this.frameMenu = new JFrame();
        panelPlaces = new JPanel();
        p1 = new JPanel();
        p2 = new JPanel();
        p3 = new JPanel();
        p4 = new JPanel();
        p4.setLayout(new GridBagLayout());
        this.panelOutros = new JPanel();
        img_5 = new JLabel("                            LUCROS: ");
        img_5.setFont(new Font("Sans Serif",Font.BOLD,25));
        this.frameMenu.setUndecorated(true);

        leftPanel = new JPanel(new GridBagLayout());
        leftPanel.setBackground(new Color(0,0,0,0));
        left = new JLabel("LUCRO TOTAL:");
        left.setFont(new Font("Sans Serif",Font.BOLD,18));
        left.setForeground(Color.BLACK);
        numleft = new JLabel("0.00€");
        numleft.setFont(new Font("Sans Serif", Font.BOLD,25));
        numleft.setForeground(Color.BLACK);

        Dimension sc = Toolkit.getDefaultToolkit().getScreenSize();
        this.frameMenu.setLocation((sc.width-850)/2,(sc.height-620)/2);

        try {
            this.frameMenu.setContentPane(new JLabel(new ImageIcon(ImageIO.read(new File("C:\\Users\\killz\\Desktop\\FCTUC\\2º ANO\\1º_Semestre\\POO\\ProjetoPoo\\Images\\dei.png")))));
        } catch (IOException e) {
            e.printStackTrace();
        }

        DefaultComboBoxModel modelo = new DefaultComboBoxModel();
        modelo.addElement("Todos");
        modelo.addElement("Exposicoes");
        modelo.addElement("Areas Desportivas");
        modelo.addElement("Jardins");
        modelo.addElement("Bares");
        tipo_local.setModel(modelo);
        tipo_local.setPreferredSize(new Dimension(120,35));

        this.frameMenu.setLayout(new BorderLayout());
        this.panelPlaces.setLayout(new BorderLayout());
        this.frameMenu.setSize(850, 620);

        this.frameMenu.add(p2,BorderLayout.NORTH);
        p2.setPreferredSize(new Dimension(100,150));
        p2.setBackground(new Color(20,200,20,0));
        p2.setLayout(new BorderLayout());
        p2.add(img_5,BorderLayout.SOUTH);

        this.frameMenu.add(p1,BorderLayout.SOUTH);
        p1.setPreferredSize(new Dimension(100,150));
        p1.setBackground(new Color(20,200,20,0));
        p1.setLayout(new GridBagLayout());

        retroceder = new JButton("Voltar ao menu");
        retroceder.setBackground(Color.RED);
        retroceder.setForeground(Color.WHITE);
        retroceder.setFont(new Font("Sans Serif",Font.BOLD,15));
        retroceder.setPreferredSize(new Dimension(150,30));

        GridBagConstraints gc = new GridBagConstraints();

        gc.gridy = 1;
        gc.gridx = 1;
        gc.ipady = 20;
        gc.ipadx = 60;
        gc.anchor = GridBagConstraints.CENTER;
        gc.insets = new Insets(10,0,15,50);
        p1.add(retroceder,gc);

        this.frameMenu.add(p3,BorderLayout.EAST);
        p3.setPreferredSize(new Dimension(10,150));
        p3.setBackground(new Color(20,200,20,0));

        this.frameMenu.add(p4,BorderLayout.WEST);
        p4.setPreferredSize(new Dimension(200,150));
        p4.setBackground(new Color(20,200,20,0));
        gc.gridy = 0;
        gc.gridx = 0;
        gc.ipady = 20;
        gc.insets = new Insets(50,25,0,20);
        gc.anchor = GridBagConstraints.CENTER;
        p4.add(tipo_local,gc);

        gc.gridy = 1;
        gc.gridx = 0;
        gc.ipady = 20;
        gc.insets = new Insets(20,25,0,40);
        gc.anchor = GridBagConstraints.CENTER;
        p4.add(leftPanel,gc);

        gc.gridy = 0;
        gc.gridx = 0;
        gc.ipady = 0;
        gc.insets = new Insets(20,25,0,40);
        gc.anchor = GridBagConstraints.CENTER;
        leftPanel.add(left,gc);
        gc.gridy =1;
        gc.gridx = 0;
        gc.ipady = 0;
        gc.insets = new Insets(10,25,0,40);
        gc.anchor = GridBagConstraints.CENTER;
        leftPanel.add(numleft,gc);

        this.frameMenu.add(panelPlaces,BorderLayout.CENTER);
        panelPlaces.setPreferredSize(new Dimension(650,500));
        panelPlaces.setBackground(new Color(20,20,20,200));

        prof.setPreferredSize(new Dimension(300,350));
        prof.setFixedCellWidth(600);
        prof.setFixedCellHeight(30);
        prof.setFont(new Font("Sans Serif",Font.BOLD,18));
        prof.setBorder(BorderFactory.createEtchedBorder());

        JScrollPane scroll = new JScrollPane(prof, JScrollPane.VERTICAL_SCROLLBAR_AS_NEEDED, JScrollPane.HORIZONTAL_SCROLLBAR_NEVER);

        retroceder.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                frameMenu.dispose();
                menuFrame();
            }
        });

        show_prof("todos");
        tipo_local.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                String c = tipo_local.getSelectedItem().toString();
                show_prof(c);
            }
        });


        panelPlaces.add(scroll,BorderLayout.CENTER);

        this.frameMenu.setDefaultCloseOperation(WindowConstants.EXIT_ON_CLOSE);
        this.frameMenu.setVisible(true);

    }

    /**
     *
     * Frames End
     *
     *
     */


    ////// Funcoes Complementares ///////

    /**
     * display de locais em JList
     * @param x
     */

    private void locais(String x){

        int comp = gestor.getBase().locais.size();
        DefaultListModel listModel = new DefaultListModel();

        if(x.equals("Bares")){                  //se o valor dado pela Jcombobox for a string bares, o mesmo se aplica aos restantes
            x = "bares";
        }else if(x.equals("Areas Desportivas")){
            x = "areaDesportiva";
        }else if(x.equals("Jardins")){
            x = "jardins";
        }else if (x.equals("Exposicoes")){
            x = "exposicao";
        }else{
            x = "todos";
        }

        for(int i = 0 ; i < comp ; i++) {
            if(gestor.getBase().locais.get(i).getClass().toString().contains(x)){ // se a classe do objeto for igual a x so mostra os objetos deste tipo
                listModel.addElement(gestor.getBase().locais.get(i).descricaoLocal + "  | Inscritos: "+gestor.getBase().locais.get(i).inLocais.size());
            }else if(x.equals("todos")){  // faz display de todos os locais
                listModel.addElement(gestor.getBase().locais.get(i).descricaoLocal + "  | Inscritos: "+gestor.getBase().locais.get(i).inLocais.size());
            }
        }
        this.listaLocais.setModel(listModel);
    }

    /**
     * informaocao do locais em popup
     * @param n
     */

    private void locais_info(int n){

        /**
         *
         * colocar as informações de cada local em popup window
         *
         */

        if(gestor.getBase().locais.get(n).getClass().toString().contains("bares")){
            see_info = new JMenuItem("                                          INFO");
            see_info.setFont(new Font("Sans-Serif",Font.BOLD,12));
            popup.add(see_info);
            see_info = new JMenuItem("Local: "+gestor.getBase().locais.get(n).descricaoLocal);
            popup.add(see_info);
            see_info = new JMenuItem("Coordenadas: "+(((bares)gestor.getBase().locais.get(n))).gps);
            popup.add(see_info);
            see_info = new JMenuItem("Lotação: "+(((bares)gestor.getBase().locais.get(n))).getLotacao());
            popup.add(see_info);
            see_info = new JMenuItem("Inscritos: "+(((bares)gestor.getBase().locais.get(n))).inLocais.size());
            popup.add(see_info);
            see_info = new JMenuItem("Consumo Minimo: "+((bares)((bares) gestor.getBase().locais.get(n))).getConsumoMin()+"€");
            popup.add(see_info);

        }else if(gestor.getBase().locais.get(n).getClass().toString().contains("exposicao")){

            see_info = new JMenuItem("                                           INFO");
            see_info.setFont(new Font("Sans-Serif",Font.BOLD,12));
            popup.add(see_info);
            see_info = new JMenuItem("Local: "+gestor.getBase().locais.get(n).descricaoLocal);
            popup.add(see_info);
            see_info = new JMenuItem("Coordenadas: "+(((exposicao)gestor.getBase().locais.get(n))).gps);
            popup.add(see_info);
            see_info = new JMenuItem("Arte: "+(((exposicao)gestor.getBase().locais.get(n))).getArte());
            popup.add(see_info);
            see_info = new JMenuItem("Inscritos: "+(((exposicao)gestor.getBase().locais.get(n))).inLocais.size());
            popup.add(see_info);
            see_info = new JMenuItem("Entrada: "+(((exposicao)gestor.getBase().locais.get(n))).getIngresso()+"€");
            popup.add(see_info);


        }else if(gestor.getBase().locais.get(n).getClass().toString().contains("jardins")){

            see_info = new JMenuItem("                                          INFO");
            see_info.setFont(new Font("Sans-Serif",Font.BOLD,12));
            popup.add(see_info);
            see_info = new JMenuItem("Local: "+gestor.getBase().locais.get(n).descricaoLocal);
            popup.add(see_info);
            see_info = new JMenuItem("Coordenadas: "+(((jardins)gestor.getBase().locais.get(n))).gps);
            popup.add(see_info);
            see_info = new JMenuItem("Area: "+(((jardins)gestor.getBase().locais.get(n))).getArea()+"m^2");
            popup.add(see_info);
            see_info = new JMenuItem("Inscritos: "+(((jardins)gestor.getBase().locais.get(n))).inLocais.size());
            popup.add(see_info);
            see_info = new JMenuItem("");
            popup.add(see_info);


        }else if(gestor.getBase().locais.get(n).getClass().toString().contains("areaDesportiva")){

            see_info = new JMenuItem("                                         INFO");
            see_info.setFont(new Font("Sans-Serif",Font.BOLD,12));
            popup.add(see_info);
            see_info = new JMenuItem("Local: "+gestor.getBase().locais.get(n).descricaoLocal);
            popup.add(see_info);
            see_info = new JMenuItem("Coordenadas: "+(((areaDesportiva)gestor.getBase().locais.get(n))).gps);
            popup.add(see_info);
            see_info = new JMenuItem("Desporto: "+(((areaDesportiva)gestor.getBase().locais.get(n))).getDesporto());
            popup.add(see_info);
            see_info = new JMenuItem("Inscritos: "+(((areaDesportiva)gestor.getBase().locais.get(n))).inLocais.size());
            popup.add(see_info);
            see_info = new JMenuItem("");
            popup.add(see_info);

        }else{

            see_info = new JMenuItem("NONE");
            popup.add(see_info);
            see_info = new JMenuItem("Coordenadas: ");
            popup.add(see_info);
            see_info = new JMenuItem("Desporto: ");
            popup.add(see_info);
            see_info = new JMenuItem("Inscritos: ");
            popup.add(see_info);
            see_info = new JMenuItem("");
            popup.add(see_info);

        }

        popup.setPreferredSize(new Dimension(300,200));


    }

    /**
     * faz o display dos inscritos
     * @param x
     */

    private void inscritos(String x){

        int comp = gestor.getBase().insc.size();
        DefaultListModel listModel = new DefaultListModel();

        if(x.equals("Alunos")){
            x = "aluno";
        }else if(x.equals("Professores")){
            x = "professor";
        }else if(x.equals("Auxiliares")){
            x = "auxiliar";
        }else{
            x = "todos";
        }

        for(int i = 0 ; i < comp ; i++) {
            if(gestor.getBase().insc.get(i).getClass().toString().contains(x)){
                listModel.addElement(gestor.getBase().insc.get(i).nome+": "+gestor.getBase().insc.get(i).perfil);
            }else if(x.equals("todos")){
                listModel.addElement(gestor.getBase().insc.get(i).nome+": "+gestor.getBase().insc.get(i).perfil);
            }
        }
        this.lista_insc.setModel(listModel);

    }

    /**
     * display dos locais escolhidos pelo utilizador
     * @param x
     */

    private void my_locais(String x){

        int comp = gestor.getNovo().going.size();
        DefaultListModel listModel = new DefaultListModel();

        if(x.equals("Bares")){
            x = "bares";
        }else if(x.equals("Areas Desportivas")){
            x = "areaDesportiva";
        }else if(x.equals("Jardins")){
            x = "jardins";
        }else if (x.equals("Exposicoes")){
            x = "exposicao";
        }else{
            x = "todos";
        }
        for(int i = 0 ; i < comp ; i++) {
            if(gestor.getNovo().going.get(i).getClass().toString().contains(x)){
                listModel.addElement(gestor.getNovo().going.get(i).descricaoLocal);
            }else if(x.equals("todos")){
                listModel.addElement(gestor.getNovo().going.get(i).descricaoLocal);
            }
        }
        this.listamylocais.setModel(listModel);

    }

    /**
     * display de pessoas por lugar
     * @param x
     */

    private void p_by_p(String x){

        int comp = gestor.getBase().locais.size();
        DefaultListModel listModel = new DefaultListModel();

        if(x.equals("Bares")){
            x = "bares";
        }else if(x.equals("Areas Desportivas")){
            x = "areaDesportiva";
        }else if(x.equals("Jardins")){
            x = "jardins";
        }else if (x.equals("Exposicoes")){
            x = "exposicao";
        }else{
            x = "todos";
        }

        for(int i = 0 ; i < comp ; i++) {
            if(gestor.getBase().locais.get(i).getClass().toString().contains(x)){
                listModel.addElement(gestor.getBase().locais.get(i).descricaoLocal + "  | Inscritos: "+gestor.getBase().locais.get(i).inLocais.size());
                for (int j = 0 ; j < gestor.getBase().locais.get(i).inLocais.size(); j++){
                    if(gestor.getBase().locais.get(i).inLocais.get(j).getClass().toString().contains("aluno")){
                        listModel.addElement("    "+(j+1)+". "+((aluno)gestor.getBase().locais.get(i).inLocais.get(j)).nome+" | Curso: "+((aluno)gestor.getBase().locais.get(i).inLocais.get(j)).getCurso()
                                +" | Perfil: "+((aluno)gestor.getBase().locais.get(i).inLocais.get(j)).perfil);
                    }else if(gestor.getBase().locais.get(i).inLocais.get(j).getClass().toString().contains("professor")){
                        listModel.addElement("    "+(j+1)+". "+((professor)gestor.getBase().locais.get(i).inLocais.get(j)).nome+" | Categoria: "+((professor)gestor.getBase().locais.get(i).inLocais.get(j)).getCatProfissional()
                                +" | Perfil: "+((professor)gestor.getBase().locais.get(i).inLocais.get(j)).perfil);
                    }else if(gestor.getBase().locais.get(i).inLocais.get(j).getClass().toString().contains("auxiliar")){
                        listModel.addElement("    "+(j+1)+". "+((auxiliar)gestor.getBase().locais.get(i).inLocais.get(j)).nome+" | Regime: "+((auxiliar)gestor.getBase().locais.get(i).inLocais.get(j)).getRegime()
                                +" | Perfil: "+((auxiliar)gestor.getBase().locais.get(i).inLocais.get(j)).perfil);
                    }
                }
            }else if(x.equals("todos")){
                listModel.addElement(gestor.getBase().locais.get(i).descricaoLocal + "  | Inscritos: "+gestor.getBase().locais.get(i).inLocais.size());
                for (int j = 0 ; j < gestor.getBase().locais.get(i).inLocais.size(); j++){
                    if(gestor.getBase().locais.get(i).inLocais.get(j).getClass().toString().contains("aluno")){
                        listModel.addElement("    "+(j+1)+". "+((aluno)gestor.getBase().locais.get(i).inLocais.get(j)).nome+" | Curso: "+((aluno)gestor.getBase().locais.get(i).inLocais.get(j)).getCurso()
                                +" | Perfil: "+((aluno)gestor.getBase().locais.get(i).inLocais.get(j)).perfil);
                    }else if(gestor.getBase().locais.get(i).inLocais.get(j).getClass().toString().contains("professor")){
                        listModel.addElement("    "+(j+1)+". "+((professor)gestor.getBase().locais.get(i).inLocais.get(j)).nome+" | Categoria: "+((professor)gestor.getBase().locais.get(i).inLocais.get(j)).getCatProfissional()
                                +" | Perfil: "+((professor)gestor.getBase().locais.get(i).inLocais.get(j)).perfil);
                    }else if(gestor.getBase().locais.get(i).inLocais.get(j).getClass().toString().contains("auxiliar")){
                        listModel.addElement("    "+(j+1)+". "+((auxiliar)gestor.getBase().locais.get(i).inLocais.get(j)).nome+" | Regime: "+((auxiliar)gestor.getBase().locais.get(i).inLocais.get(j)).getRegime()
                                +" | Perfil: "+((auxiliar)gestor.getBase().locais.get(i).inLocais.get(j)).perfil);
                    }
                }
            }
        }
        this.pbp.setModel(listModel);


    }

    /**
     * dipslay das guest lists
     */

    private void guests() {

        convivioDei pessoa;

        int comp = gestor.getBase().locais.size();
        DefaultListModel listModel = new DefaultListModel();

        for (int i = 0; i < comp; i++) {
            if (gestor.getBase().locais.get(i).getClass().toString().contains("bares")) {
                listModel.addElement(gestor.getBase().locais.get(i).descricaoLocal + "  | Inscritos: " + gestor.getBase().locais.get(i).inLocais.size());
                for (int j = 0; j < ((bares) gestor.getBase().locais.get(i)).getGuest().size(); j++) {
                    if (((bares) gestor.getBase().locais.get(i)).getGuest().get(j).getClass().toString().contains("aluno")) {
                        pessoa = ((bares) gestor.getBase().locais.get(i)).getGuest().get(j);
                        listModel.addElement("    " + (j + 1) + ". Nome: " + ((aluno) pessoa).nome + "  | Curso: " + ((aluno) pessoa).getCurso() + "  | Perfil: " + ((aluno) pessoa).perfil);
                    }

                    else if (((bares) gestor.getBase().locais.get(i)).getGuest().get(j).getClass().toString().contains("professor")) {
                        pessoa = ((bares) gestor.getBase().locais.get(i)).getGuest().get(j);
                        listModel.addElement("    " + (j + 1) + ". Nome: " + ((professor) pessoa).nome + "  | Perfil: " + ((professor) pessoa).perfil);
                    }



                    else if (((bares) gestor.getBase().locais.get(i)).getGuest().get(j).getClass().toString().contains("auxiliar")) {
                        pessoa = ((bares) gestor.getBase().locais.get(i)).getGuest().get(j);
                        listModel.addElement("    " + (j + 1) + ". Nome: " + ((auxiliar) pessoa).nome + "  | Perfil: " + ((auxiliar) pessoa).perfil);
                    }
                }
            }

        }
        this.gl.setModel(listModel);
    }

    /**
     * display dos lucros de cada local
     * @param x
     */

    private void show_prof(String x){

        int comp = gestor.getBase().locais.size();
        DefaultListModel listModel = new DefaultListModel();
        double total = 0;

        if(x.equals("Bares")){
            x = "bares";
        }else if(x.equals("Areas Desportivas")){
            x = "areaDesportiva";
        }else if(x.equals("Jardins")){
            x = "jardins";
        }else if (x.equals("Exposicoes")){
            x = "exposicao";
        }else{
            x = "todos";
        }

        for(int i = 0 ; i < comp ; i++) {

            if (x.equals("bares") && gestor.getBase().locais.get(i).getClass().toString().contains("bares")) {
                listModel.addElement(((bares) gestor.getBase().locais.get(i)).descricaoLocal + " | Inscritos: "
                        + ((bares) gestor.getBase().locais.get(i)).inLocais.size()
                        + " | Lucro: " + ((bares) gestor.getBase().locais.get(i)).getLucro());
                total += ((bares) gestor.getBase().locais.get(i)).getLucro();
            } else if (x.equals("exposicao")&& gestor.getBase().locais.get(i).getClass().toString().contains("exposicao")) {
                listModel.addElement(((exposicao) gestor.getBase().locais.get(i)).descricaoLocal + " | Inscritos: "
                        + ((exposicao) gestor.getBase().locais.get(i)).inLocais.size()
                        + " | Lucro: " + ((exposicao) gestor.getBase().locais.get(i)).getLucro());
                total += ((exposicao) gestor.getBase().locais.get(i)).getLucro();
            } else if (x.equals("jardins") && gestor.getBase().locais.get(i).getClass().toString().contains("jardins")) {
                listModel.addElement(gestor.getBase().locais.get(i).descricaoLocal + " | Inscritos: "
                        + gestor.getBase().locais.get(i).inLocais.size()
                        + " | Lucro: Nao gera lucro.");
            } else if (x.equals("areaDesportiva") && gestor.getBase().locais.get(i).getClass().toString().contains("areaDesportiva")) {
                listModel.addElement(gestor.getBase().locais.get(i).descricaoLocal + " | Inscritos: "
                        + gestor.getBase().locais.get(i).inLocais.size()
                        + " | Lucro: Nao gera lucro.");
            } else if (x.equals("todos")) {

                if (gestor.getBase().locais.get(i).getClass().toString().contains("bares")) {
                    listModel.addElement(((bares) gestor.getBase().locais.get(i)).descricaoLocal + " | Inscritos: "
                            + ((bares) gestor.getBase().locais.get(i)).inLocais.size()
                            + " | Lucro: " + ((bares) gestor.getBase().locais.get(i)).getLucro());
                    total += ((bares) gestor.getBase().locais.get(i)).getLucro();
                } else if (gestor.getBase().locais.get(i).getClass().toString().contains("exposicao")) {
                    listModel.addElement(((exposicao) gestor.getBase().locais.get(i)).descricaoLocal + " | Inscritos: "
                            + ((exposicao) gestor.getBase().locais.get(i)).inLocais.size()
                            + " | Lucro: " + ((exposicao) gestor.getBase().locais.get(i)).getLucro());
                    total += ((exposicao) gestor.getBase().locais.get(i)).getLucro();
                } else if (gestor.getBase().locais.get(i).getClass().toString().contains("jardins")) {
                    listModel.addElement(gestor.getBase().locais.get(i).descricaoLocal + " | Inscritos: "
                            + gestor.getBase().locais.get(i).inLocais.size()
                            + " | Lucro: Nao gera lucro.");
                }else if (gestor.getBase().locais.get(i).getClass().toString().contains("areaDesportiva")) {
                    listModel.addElement(gestor.getBase().locais.get(i).descricaoLocal + " | Inscritos: "
                            + gestor.getBase().locais.get(i).inLocais.size()
                            + " | Lucro: Nao gera lucro.");
                }
            }
        }
        numleft.setText(String.valueOf(total) + "€");
        numleft.setFont(new Font("Sans Serif", Font.BOLD, 18));
        this.prof.setModel(listModel);
    }

}


