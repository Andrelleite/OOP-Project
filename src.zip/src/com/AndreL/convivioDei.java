package com.AndreL;

import java.io.Serializable;
import java.util.LinkedList;
import java.util.List;

/**
 *
 * Criação de pessoas para convivio
 *
 *
 */


public class convivioDei implements Serializable {

    protected String perfil; // perfil de inscrito
    protected String password; // password do inscrito
    protected String id; // numero de uc
    protected String nome; // nome do inscrito
    protected Ficheiros fich; // objeto ficheiro para permitir escrita a partir da classe
    protected String mail; // mail do inscrito
    protected List<Locais> going; // lista de locais selecionados pelo inscrito

    public convivioDei() {
        this.nome = "None";
        this.id = "None";
        this.perfil = "None";
        this.mail = "mail@mail.com";
        this.password = "default";
        this.going = new LinkedList<>();
    }

    /**
     * escrita em ficheiro deste objeto
     */

    public void inscreve(){
        fich = new Ficheiros();
        fich.writeFile("C:\\Users\\killz\\Desktop\\FCTUC\\2º ANO\\1º_Semestre\\POO\\ProjetoPoo\\Files\\baseDadosInscritos",convivioDei.this);
    }

    /**
     * adição de um local na lista de locais
     * @param x
     */

    public void addLocal(Locais x){
        going.add(x);
    }

}

class aluno extends convivioDei{

    private String curso; // curso referente a uma pessoa do tipo aluno
    private double promo = 0.10; // desconto referente ao aluno

    /**
     * Construtor do objeto do tipo aluno que herda da classe abstrata convivioDei
     * @param curso
     * @param password
     * @param nome
     * @param id
     * @param perfil
     * @param mail
     */


    public aluno(String curso,String password, String nome, String id, String perfil, String mail) {
        this.curso = curso;
        super.nome = nome;
        super.id = id;
        super.perfil = perfil;
        super.mail = mail;
        super.password = password;
        super.going = new LinkedList<>();
        inscreve();
    }

    /**
     * obter o curso do aluno
     * @return
     */

    public String getCurso() {
        return curso;
    }

    /**
     * get desconto do aluno
     * @return
     */

    public double getPromo(){
        return promo;
    }

    /**
     * escreve esta pessoa no ficheiro de texto
     */
    @Override
    public void inscreve(){

        fich = new Ficheiros();
        fich.writeFile("C:\\Users\\killz\\Desktop\\FCTUC\\2º ANO\\1º_Semestre\\POO\\ProjetoPoo\\Files\\baseDadosInscritos",aluno.this);

    }

    /**
     *
     * @param x
     */

    @Override
    public void addLocal(Locais x){
        going.add(x);
    }

}

class professor extends convivioDei{

    private String catProfissional; // caracteristica referente ao objeto do tipo professor

    public professor(String catProfissional,String password, String nome, String id, String perfil, String mail) {
        this.catProfissional = catProfissional;
        super.id = id;
        super.nome = nome;
        super.perfil = perfil;
        super.mail = mail;
        super.password = password;
        super.going = new LinkedList<>();
        inscreve();


    }

    public String getCatProfissional() {
        return catProfissional;
    }

    @Override
    public void inscreve(){

        fich = new Ficheiros();
        fich.writeFile("C:\\Users\\killz\\Desktop\\FCTUC\\2º ANO\\1º_Semestre\\POO\\ProjetoPoo\\Files\\baseDadosInscritos",professor.this);

    }

    @Override
    public void addLocal(Locais x){
        going.add(x);
    }

}

class auxiliar extends convivioDei{

    private String regime;

    public auxiliar(String regime,String password, String nome, String id, String perfil, String mail) {
        this.regime = regime;
        super.id = id;
        super.nome = nome;
        super.perfil = perfil;
        super.mail = mail;
        super.password = password;

        inscreve();

    }

    public String getRegime() {
        return regime;
    }

    @Override
    public void inscreve(){
        fich = new Ficheiros();
        fich.writeFile("C:\\Users\\killz\\Desktop\\FCTUC\\2º ANO\\1º_Semestre\\POO\\ProjetoPoo\\Files\\baseDadosInscritos",auxiliar.this);
    }

    @Override
    public void addLocal(Locais x){
        going.add(x);
    }
}