package com.AndreL;

import java.io.*;
import java.lang.reflect.Array;
import java.util.*;


/**
 *
 * classe para manipular ficheiros
 *
 */

public class Ficheiros implements Serializable{

//   --------------------------------------PESSOAS---------------------------------

    /**
     * ler ficheiro texto inscritos
     * @param fileName
     * @param lista
     * @return
     */

    public List<String[]> readFile(String fileName, List<String[]> lista){
        String[] info;
        try {
            File novo = new File(fileName); // abre ficheiro
            FileReader leFich = new FileReader(novo);
            BufferedReader br = new BufferedReader(leFich);
            Scanner sc = new Scanner(br);
            sc.nextLine();                                  //Passa o titulo à frente. Passa para as linhas de informação
            while (sc.hasNextLine()) {
                String nome = sc.nextLine();
                info = new String[nome.split(" - ").length]; //parte a string seprando as palavras por -
                info = nome.split(" - ");              // passa o caracter '-' à frente
                lista.add(info);                             //Guarda em array a informação de cada pessoa no DEI
            }
            leFich.close();
            br.close();

        }catch (IOException e){
            e.printStackTrace();
        }
        return lista;
    }

    /**
     * escrever ficheiro de texto para inscritos
     * @param fileName
     * @param pessoa
     */

    public void writeFile(String fileName, convivioDei pessoa ){
        try{

            File fich =  new File(fileName);
            FileReader leFich = new FileReader(fich);
            BufferedReader br = new BufferedReader(leFich);
            FileWriter fw = new FileWriter(fich.getAbsoluteFile(),true);
            BufferedWriter bw = new BufferedWriter(fw);
            Scanner scan = new Scanner(br);

            if(scan.hasNextLine() == false){  // se o ficheiro estiver vazia introduz o titulo
                fw = new FileWriter(fich);
                bw = new BufferedWriter(fw);
                bw.write("___________________________ Ficheiro de inscritos ___________________________");
                System.out.println("A criar ficheiro");
            }
            bw.newLine();
            if (pessoa.getClass().toString().contains("aluno")) {
                bw.write(pessoa.nome + " - " + pessoa.id + " - " + ((aluno) pessoa).getCurso() + " - " + pessoa.perfil + ";");
            } else if (pessoa.getClass().toString().contains("professor")) {
                bw.write(pessoa.nome + " - " + pessoa.id + " - " + ((professor) pessoa).getCatProfissional() + " - " + pessoa.perfil + ";");
            } else if (pessoa.getClass().toString().contains("auxiliar")) {
                bw.write(pessoa.nome + " - " + pessoa.id + " - " + ((auxiliar) pessoa).getRegime() + " - " + pessoa.perfil + ";");
            } else {
                bw.write(pessoa.nome + " - " + pessoa.id + ";");
            }
            bw.flush();
            bw.close();

        }catch(IOException e){
            e.printStackTrace();
        }
    }

    /**
     * escreve ficheiro objetos para inscritos
     * @param fileName
     * @param ob
     */

    public void writeFileOb(String fileName, List<convivioDei> ob) {
        try{
            File f = new File(fileName);
            FileOutputStream fos = new FileOutputStream(f);
            ObjectOutputStream bos = new ObjectOutputStream(fos);

            bos.writeObject(ob);

            bos.flush();
            bos.close();
            fos.close();

        }catch(IOException e){
            e.printStackTrace();
        }

    }

    /**
     * ler ficheiro objetos para inscritos
     * @param fileName
     * @return
     */

    public LinkedList<convivioDei> readFileOb(String fileName) {
        boolean condition = true;
        List<convivioDei> deserializeList = new LinkedList<>(); // inicializa lista vazia para guarda os inscritos em ficheiro

        File f = new File(fileName);
        try {
            FileInputStream fis = new FileInputStream(f);
            if(fis.available() != 0) { //se o ficheiro nao estiver vazio
                ObjectInputStream ois = new ObjectInputStream(fis);
                Scanner in = new Scanner(f);
                deserializeList = (List<convivioDei>) ois.readObject(); // igual a lista à que estava escrita no ficheiro objeto
                ois.close();
                fis.close();
            }else{                // o ficheiro está vazio
                fis.close();
                System.out.println("File Empty!");
            }

        } catch (FileNotFoundException e) {
            System.out.println("File not found");
        } catch (EOFException e){
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        } catch (ClassNotFoundException e) {
            e.printStackTrace();
        }

        return (LinkedList<convivioDei>) deserializeList;
    }

    /**
     * remove inscrito do ficheiro de objeto
     * @param fileName
     * @param id
     */

    public void removeInscrito(String fileName, String id){
        try{
            File file = new File(fileName);
            FileReader fr = new FileReader(file);
            BufferedReader br = new BufferedReader(fr);
            Scanner scan = new Scanner(br);
            String linha;
            String buff = "";
            while(scan.hasNextLine()){
                linha = scan.nextLine();
                if(!(linha.contains(id))) {  // se a string nao contem o id do objeto
                    buff += linha;  // buff adiciona a string
                    buff += '\n';  // adiciona /n para ir para a linha abaixo
                }else{                  // se a string tiver o id passa para o proximo objeto nao escrevendo o atual
                    continue;
                }
            }
            br.close();
            fr.close();

            FileWriter fw = new FileWriter(fileName);
            BufferedWriter bw = new BufferedWriter(fw);
            bw.write(buff);

            bw.flush();
            bw.close();
            fr.close();

        }catch (IOException e){
            e.printStackTrace();
        }

    }

//    --------------------------------------LOCAIS---------------------------------

    /**
     * escrever ficheiro texto locais
     * @param fileName
     * @param local
     */

    public void writeFileLocals(String fileName, Locais local ){
        try{

            File fich =  new File(fileName);
            FileReader leFich = new FileReader(fich);
            BufferedReader br = new BufferedReader(leFich);
            FileWriter fw = new FileWriter(fich.getAbsoluteFile(),true);
            BufferedWriter bw = new BufferedWriter(fw);
            Scanner scan = new Scanner(br);

            if(scan.hasNextLine() == false){
                fw = new FileWriter(fich);
                bw = new BufferedWriter(fw);
                bw.write("___________________________ Ficheiro de Locais ___________________________");
                System.out.println("A criar ficheiro");
            }

            bw.newLine();
            if(local.getClass().toString().contains("bares")){
                bw.write("Descrição: "+local.descricaoLocal+" | Localização: "+local.gps+" | Lotação Máxima: "+((bares)local).getLotacao()+" | Consumo Minimo: "+((bares)local).getConsumoMin()+"€");
            }else if(local.getClass().toString().contains("jardins")){
                bw.write("Descrição: "+local.descricaoLocal+" | Localização: "+local.gps+" | Area (m^2): "+((jardins)local).getArea()+" m^2");
            }else if(local.getClass().toString().contains("areaDesportiva")){
                bw.write("Descrição: "+local.descricaoLocal+" | Localização: "+local.gps+" | Desporto: "+((areaDesportiva)local).getDesporto());
            }else{
                bw.write("Descrição: "+local.descricaoLocal+" | Localização: "+local.gps+" | Arte: "+((exposicao)local).getArte()+" | Ingresso: "+((exposicao)local).getIngresso()+"€");
            }

            bw.flush();
            leFich.close();
            bw.close();

        }catch(IOException e){
            e.printStackTrace();
        }
    }

    /**
     * escrever ficheiro objeto locais
     * @param fileName
     * @param ob
     */

    public void writeFileObLocals(String fileName, List<Locais> ob) {
        try{
            File f = new File(fileName);
            FileOutputStream fos = new FileOutputStream(f);
            ObjectOutputStream bos = new ObjectOutputStream(fos);

            bos.writeObject(ob);

            bos.flush();
            bos.close();
            fos.close();
            System.out.println("Object inserted with success");

        }catch(IOException e){
            e.printStackTrace();
        }

    }

    /**
     * ler ficheiro objeto locais
     * @param fileName
     * @return
     */

    public LinkedList<Locais> readFileObLocals(String fileName) {
        boolean condition = true;
        List<Locais> deserializeList = new LinkedList<>();

        File f = new File(fileName);
        try {
            FileInputStream fis = new FileInputStream(f);
            if(fis.available() != 0) {
                ObjectInputStream ois = new ObjectInputStream(fis);
                Scanner in = new Scanner(f);
                deserializeList = (List<Locais>) ois.readObject();
                ois.close();
                fis.close();
            }else{
                fis.close();
                System.out.println("File Empty!");
            }

        } catch (FileNotFoundException e) {
            System.out.println("File not found");
        } catch (EOFException e){
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        } catch (ClassNotFoundException e) {
            e.printStackTrace();
        }

        return (LinkedList<Locais>) deserializeList;
    }
}